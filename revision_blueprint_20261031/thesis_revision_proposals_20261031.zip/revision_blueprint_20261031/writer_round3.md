# 第三轮冻结候选稿

这是reviewer_round2后的定点小修稿。仅修R1-33的F11a/F11b及三处过时中文说明；已通过的97条局部候选文字不重写。round1、round2、working和来源文件冻结保留。本轮没有修改thesis源、论文PDF、作者回复、数据、bibliography或图片，没有实验/编译/提交。

作者YES/NO和路线只在第三编辑维护的唯一清单填写。本文件的“推荐”是编辑判断，不是作者批准；所有实施状态仍为【未执行】，最终页码【待基线／编译核验】。待核验run和刺激来源不因文字返修而关闭。

A最小，B补局部理由，C改善局部叙述。43项仍完整覆盖；局部A/B/C与单稿沿用round2复审文字，R1-33的共同同步段在本轮修复。下表状态承接reviewer_round2：38项可供作者选择、4项受证据阻塞、R1-33待最终定点核验。R1-21的未定timing协议仍留在正文候选外。

working中的162条是短稿／组件草图与取舍，不是162个完整独立段落或历史轮次证据。可观察循环为writer round1 → independent reviewer round1 → writer round2 → independent reviewer round2 → 本次定点小修。最终定点核验尚待完成。另一位GPT-6.1仅看过5个摘录，未把它称作全书审查。

## 当前推荐与定点核验索引

| ID | 修改点 | 当前推荐 | 本轮状态 |
| --- | --- | --- | --- |
| [R1-01](#r1-01) | 引用体例由作者决定，不为可选建议重写全文 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-02](#r1-02) | 更新 ISMIR 接收状态 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-03](#r1-03) | Fig.1.1 补足乐器身份和其他表达因素 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-04](#r1-04) | recollecting 改 collecting | A | ready-for-author-choice；仍未批准／实施 |
| [R1-05](#r1-05) | 定义 weakly expressive 与 weakly supervised | B | ready-for-author-choice；仍未批准／实施 |
| [R1-06](#r1-06) | S3 不是所有 audio-only 输出的总称 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-07](#r1-07) | Fig.2.1 是多种关系，不是必经 MIDI 的链 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-08](#r1-08) | Bark 表每组三列加分隔线 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-09](#r1-09) | 把 onset 说法限定为本文的 Note On velocity | B | ready-for-author-choice；仍未批准／实施 |
| [R1-10](#r1-10) | Fig.2.3 颜色不能猜含义 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-11](#r1-11) | humanisation 用一行定义 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-12](#r1-12) | crescendo 已有定义，只补定位与范围 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-13](#r1-13) | 数据表拆清 note events、performance velocity、score 与音频可用性 | A | evidence-blocked；局部文字可选，关键字段待核 |
| [R1-14](#r1-14) | 背景定义常用指标，同时保留 Ch.5 平均方式待核验 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-15](#r1-15) | 用信息条件描述 S1，不用单一难度排序 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-16](#r1-16) | 区分跨曲目使用与风格控制 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-17](#r1-17) | image-like 的含义与 piano-roll 选择一起解释 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-18](#r1-18) | piano roll 与 event list 的取舍 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-19](#r1-19) | recovery 是实验构造，estimation 是一般任务 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-20](#r1-20) | physical time 是兼容性选择，不是 beat-alignment 劣势的证明 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-21](#r1-21) | 量化 MIDI 听测保留作者说明，待刺激记录对齐 | A | evidence-blocked；局部文字可选，关键字段待核 |
| [R1-22](#r1-22) | 单列 baselines，重排已有事实即可 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-23](#r1-23) | modular correction 的实际适用范围与联合模型互补 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-24](#r1-24) | Ch.4 实际上是矩阵接口加 onset tokens | A | ready-for-author-choice；仍未批准／实施 |
| [R1-25](#r1-25) | 明确 hybrid loss 的相对权重与证据边界 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-26](#r1-26) | Table4.1 每个 setup 用现有变量逐一解释 | A | evidence-blocked；局部文字可选，关键字段待核 |
| [R1-27](#r1-27) | 完整 AMT 集成作为未来方向，不虚报已验证性能 | A（Ch.5）；C（Ch.7，与R1-37合并） | ready-for-author-choice；仍未批准／实施 |
| [R1-28](#r1-28) | state 与 boundary 是互补监督，并非二选一 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-29](#r1-29) | 共享表征、分头 loss 与 decoding 连接同时说明 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-30](#r1-30) | cross-dataset 是测迁移边界，不是分离风格因果 | B | evidence-blocked；局部文字可选，关键字段待核 |
| [R1-31](#r1-31) | 不用未测的 simpler 或 efficiency 优越性 | B | ready-for-author-choice；仍未批准／实施 |
| [R1-32](#r1-32) | V^(0) 是粗估 roll，Vhat 是 correction 后的逐音值 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-33](#r1-33) | DDSP fidelity 是限制，退化不等于因果证明 | B | 定点小修完成，待最终独立核验 |
| [R1-34](#r1-34) | Huber 的梯度理由与 MAE 对照边界 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-35](#r1-35) | Fig6.2 已提 rendered audio，补图内 teacher 路径 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-36](#r1-36) | 自动选择 SoundFont 留为明确未来工作 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-37](#r1-37) | 完整 AMT 与 note accuracy 的回应统一放一处 | A | ready-for-author-choice；仍未批准／实施 |
| [R1-38](#r1-38) | 明确未显式恢复渐强渐弱，加入 span 输出方向 | B | ready-for-author-choice；仍未批准／实施 |
| [R2-01](#r2-01) | 现有章节首尾已经显式回应中心问题，推荐保留 | A | ready-for-author-choice；仍未批准／实施 |
| [R2-02](#r2-02) | 四篇论文的技术贡献与 thesis 新增综合分开 | B | ready-for-author-choice；仍未批准／实施 |
| [R2-03](#r2-03) | 把 beyond-piano 可迁移与未验证部分写具体 | B | ready-for-author-choice；仍未批准／实施 |
| [R2-04](#r2-04) | 11位听者与8段刺激是补充证据，避免 definitive validation | A | ready-for-author-choice；仍未批准／实施 |
| [R2-05](#r2-05) | 只列实际见到的语言／格式问题 | A | ready-for-author-choice；仍未批准／实施 |

<a id="r1-01"></a>

## R1-01 引用体例由作者决定，不为可选建议重写全文

**操作**：保留方案：正文无替换。若作者选择 author–year，另做全局排版与引用检查，不能只改一行命令就宣称完成。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`main.tex` line 48

```latex
% --------------------- Bibliography and hyperlinks ---------------------
\usepackage[square,numbers,sort&compress]{natbib}
\setlength\bibhang{.3in}
\usepackage[colorlinks=true,
                            citecolor=black,
                            linkcolor=black,
                            urlcolor=red,
                            linktocpage=true,
                            hyperfootnotes=false]{hyperref}
```

### A

No thesis prose change is proposed. Retain the existing numeric citation style consistently throughout the thesis.

**评价与推荐**：评审是 suggest，未要求必须转换。整篇转换会改变引用宽度与页码；目前没有作者立场。此项应留给人工选择，不把作者未回复当成接受。

**待核验／边界**：【作者决定：保留 numeric / 改 author–year】。如改，natbib 参数、bibliographystyle、文内作者姓名引用、最终布局须一并核验。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-02"></a>

## R1-02 更新 ISMIR 接收状态

**操作**：只替换第四篇声明中的状态行，题名与作者保持不变。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Declaration/author_declaration.tex` line 41

```latex
\begin{tabular}{@{}p{\dimexpr\textwidth-2\tabcolsep\relax}@{}}
\textbf{Details of the work:} \\
\textbf{Zhanhong He}, Hanyu Meng, Defeng (David) Huang, Roberto Togneri,\\
``Joint Estimation of Piano Dynamics and Metrical Structure with a Multi-task Multi-Scale Network,''\\
\emph{Proc.\ IEEE International Conference on Acoustics, Speech, and Signal Processing (ICASSP)},
pp.~14607--14611, 2026.\\
% arXiv:2510.18190. DOI: 10.48550/arXiv.2510.18190.\\%[0.3cm]
\textbf{Location in thesis: Chapter 5} \\
\textbf{Student contribution to work: 80\%}\\
% {[insert text: describe your contribution vs.\ co-authors (methods, data, experiments, writing, etc.)]}
%\\[0.3cm]
%\textbf{Co-author signatures and dates:} \\
%Hanyu Meng:\ \rule{6cm}{0.4pt}\ \ \ Date:\ \rule{3cm}{0.4pt}\\
%David Huang:\ \rule{6cm}{0.4pt}\ \ \ Date:\ \rule{3cm}{0.4pt}\\
%Roberto Togneri:\ \rule{6cm}{0.4pt}\ \ \ Date:\ \rule{3cm}{0.4pt}
\end{tabular} 
	
\vskip 0.6cm
	
\begin{tabular}{@{}p{\dimexpr\textwidth-2\tabcolsep\relax}@{}}
\textbf{Details of the work:} \\
\textbf{Zhanhong He}, Hanyu Meng, Defeng (David) Huang, Roberto Togneri,\\
``Beyond Piano: Cross-Instrument MIDI Velocity Estimation via Differentiable SoundFont Proxies,''\\
Under review (\emph{International Society for Music Information Retrieval (ISMIR)} Conference), 2026.\\
% arXiv:2510.18190. DOI: 10.48550/arXiv.2510.18190.\\%[0.3cm]
\textbf{Location in thesis: Chapter 6} \\
\textbf{Student contribution to work: 80\%}\\
% {[insert text: describe your contribution vs.\ co-authors (methods, data, experiments, writing, etc.)]}
%\\[0.3cm]
%\textbf{Co-author signatures and dates:} \\
%Hanyu Meng:\ \rule{6cm}{0.4pt}\ \ \ Date:\ \rule{3cm}{0.4pt}\\
%David Huang:\ \rule{6cm}{0.4pt}\ \ \ Date:\ \rule{3cm}{0.4pt}\\
%Roberto Togneri:\ \rule{6cm}{0.4pt}\ \ \ Date:\ \rule{3cm}{0.4pt}
\end{tabular}
```

### A

Accepted for publication in the \emph{International Society for Music Information Retrieval (ISMIR) Conference}, 2026.

**评价与推荐**：报告 1 Preamble 明确 accepted，所给 ISMIR PDF 为该文的会议版。只写 accepted，不凭相机稿文件名宣称正式出版。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-03"></a>

## R1-03 Fig.1.1 补足乐器身份和其他表达因素

**操作**：下列为候选图内英文标签与完整 caption；须在提案副本绘图后核验，不覆盖原图。A 保留布局，B 加支路，C 改为并列输出。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_1/Intro.tex` line 24

```latex
\begin{figure}[h!]
  \centering
  \includegraphics[width=\linewidth]{Chapter_1/figures/AMT.png}
  \caption{The general architecture of an AMT system, illustrating the transformation of raw acoustic audio into foundational note events and expressive dynamic information. The outputs are MIDI data and musical scores.}
  \label{fig:intro_expressive_amt}
\end{figure}
```

### A

Figure labels: Step 1: Note events and instrument identity. Estimate pitch, onset, duration, and instrument identity. Step 2: Expressive information. Estimate MIDI velocity and score dynamics, together with instrument-specific controls such as pedalling and articulation. Highlight MIDI velocity and score dynamics as the thesis focus.

Caption: A conceptual view of AMT, including note events, instrument identity, and expressive information. MIDI velocity and score dynamics are the expressive targets studied in this thesis.

### B

Figure labels: Note events: pitch, onset, and duration. Instrument identity: instrument or source assignment. Expressive information: dynamics, articulation, pedalling, and other instrument-specific controls. Connect these outputs to MIDI and score representations, and highlight the dynamics branch.

Caption: Main information layers in an AMT output. Note content, instrument identity, and expressive controls contribute to a symbolic representation of a performance. This thesis studies the recovery of MIDI velocity and score dynamics.

### C

Figure labels: Performance audio → Acoustic analysis → Note events / Instrument identity / Expressive controls. Within expressive controls, highlight MIDI velocity and score dynamics; show articulation and pedalling as further examples.

Caption: Conceptual outputs of expressive AMT. The branches identify complementary information layers rather than a required sequence of independent processing stages. The highlighted dynamics outputs define the scope of this thesis.

**评价与推荐**：A 直接落实作者“在图中补进”承诺且改图最少。B 更易区分内容；C 避免把两步流程误当唯一架构，但重画幅度最大。三稿均不声称本文估计了所有表达控制。

**待核验／边界**：【待绘图副本】【待视觉核验】；现图还含 every music notes、exact 等表述，可在副本改为 note events，避免准确率绝对化。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-04"></a>

## R1-04 recollecting 改 collecting

**操作**：只替换一个词，其他语句的可选精简另见 R2-05。

**独立审查处理**：通过；采用可选自然措辞collecting new data from scratch，仍只改单词/局部表达。

**实际原文与定位**

`Chapter_1/Intro.tex` line 45

```latex
By contrast, recollecting new datasets from scratch is a costly process constrained by audio-to-score synchronisation challenges, required musical expertise, and copyright restrictions \cite{li2019urmp,foscarin2020asap,morsi2022bottlenecks}. Therefore, this thesis treats \emph{label recovery} as a scalable, principled strategy. By retroactively estimating missing dynamics on existing corpora, we entirely bypass acquisition bottlenecks and annotation ambiguities, unlocking a vast, previously untapped resource for data-driven music research.
```

### A

collecting

**评价与推荐**：作者已明确接受，无需 A/B/C。

**逐句同步提案**

- `Chapter_7/Conclusion.tex` line 150
  - 原：without recollecting them from scratch.
  - 拟：without collecting new data from scratch.

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-05"></a>

## R1-05 定义 weakly expressive 与 weakly supervised

**操作**：在 §1.5 中心问题后、三场景介绍前插入一段。

**独立审查处理**：接受逐稿表的小建议：加conditions may overlap，不把数据状态/监督条件写成互斥类别。

**实际原文与定位**

`Chapter_1/Intro.tex` line 114

```latex
The thesis is driven by the following question:
\begin{quote}
\textbf{How can musically interpretable dynamics labels be recovered from incomplete, weakly expressive, or weakly supervised music data without rewriting note content or note timing?}
\end{quote}
This question is studied under three core scenarios, outlined in Table~\ref{tab:intro_scenarios}. These scenarios represent a clear methodological progression. \textbf{Scenario S1} isolates the recovery task to a strict \textit{symbolic-only} setting. \textbf{Scenario S2} introduces acoustic evidence but maintains a reliable structural prior via an \textit{audio-plus-score} alignment. Finally, \textbf{Scenario S3} removes structural support entirely, tackling the fully open, \textit{audio-only} setting to recover a \textit{score-facing} target. By intentionally ordering these environments from the tightly constrained to the ambiguous, they form the core empirical arc of the thesis.
```

### A

Here, weakly expressive data retain useful note structure but provide a simplified dynamics layer, for example MIDI with all velocities set to 64 or with only coarse dynamic levels. Weak supervision refers to settings in which the target dynamics labels are missing, incomplete, or unreliable, so learning relies partly on indirect evidence. These conditions can overlap in the same dataset.

### B

In this thesis, incomplete data lack the dynamics layer of interest, whereas weakly expressive data contain that layer only in a simplified form, such as constant or coarsely quantised MIDI velocities. Weakly supervised settings lack reliable target labels for direct training; Chapter 6 instead uses real audio and a renderer-based comparison to supervise the velocity estimator indirectly. These terms describe the available information rather than the quality of the musical performance. These conditions can overlap in the same dataset.

### C

The three terms describe different deficiencies in the available data. Incomplete data omit a required dynamics label; weakly expressive data retain note content and timing but flatten or coarsen the dynamics; and weakly supervised data provide no reliable direct target for learning. The last condition motivates the proxy-supervised extension in Chapter 6, while the first two motivate recovery or refinement of an existing symbolic layer. These conditions can overlap in the same dataset.

**评价与推荐**：B 把数据状态和学习监督条件分开，并用 Ch.6 已有方法落地。A 最短；C 衔接好但对三词分类较硬，现实数据可以同时具备多种状态。不会把八级 score dynamics 本身等同“差”的数据。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-06"></a>

## R1-06 S3 不是所有 audio-only 输出的总称

**操作**：在 Table 1.2 后补充；同步将同节“from tightly constrained to ambiguous”的总排序改为“different combinations of evidence and target representation”。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_1/Intro.tex` line 114

```latex
The thesis is driven by the following question:
\begin{quote}
\textbf{How can musically interpretable dynamics labels be recovered from incomplete, weakly expressive, or weakly supervised music data without rewriting note content or note timing?}
\end{quote}
This question is studied under three core scenarios, outlined in Table~\ref{tab:intro_scenarios}. These scenarios represent a clear methodological progression. \textbf{Scenario S1} isolates the recovery task to a strict \textit{symbolic-only} setting. \textbf{Scenario S2} introduces acoustic evidence but maintains a reliable structural prior via an \textit{audio-plus-score} alignment. Finally, \textbf{Scenario S3} removes structural support entirely, tackling the fully open, \textit{audio-only} setting to recover a \textit{score-facing} target. By intentionally ordering these environments from the tightly constrained to the ambiguous, they form the core empirical arc of the thesis.
```

`Chapter_6/chap6.tex` line 14

```latex
From the thesis perspective, this chapter occupies a distinct position. It keeps the note-level MIDI velocity target and the score-informed VeloEst architecture introduced in Chapter~\ref{ch:scoreinf}, but it relaxes the assumption that ground-truth velocity labels are available for the target instrument. It complements Chapter~\ref{ch:audiodyn}, which addressed Scenario~S3 with a different output (beat-synchronous score dynamics), by extending the velocity-focused work to a label-scarce setting. The chapter therefore contributes to thesis Requirement~R5 by combining numerical diagnostics, perceptual loudness correlations, and renderer-robust evaluation evidence, and to Requirement~R6 by treating beyond-piano transfer as a missing-supervision problem rather than ordinary acoustic domain shift.
```

### A

The scenarios describe the studies undertaken here rather than every possible audio-to-symbolic task. Chapter 6 extends S2 by retaining audio and aligned note events while replacing target-domain velocity labels with indirect renderer-based supervision. Audio-only adaptation for MIDI velocity estimation is a possible extension, but is not evaluated in this thesis.

### B

The input condition alone does not determine the dynamics target. Audio-only MIDI velocity estimation is also possible, but S3 refers specifically to the score-dynamics task studied in Chapter 5. The beyond-piano study in Chapter 6 uses the score-informed estimator from Chapter 4 and still requires aligned note events. It therefore extends S2 under weaker target-domain supervision rather than adding an audio-only velocity experiment.

### C

Table 1.2 separates three studied input–output settings. S1 predicts velocity from symbolic context, S2 refines velocity using audio and aligned notes, and S3 predicts score dynamics together with metre from audio. Chapter 6 returns to the S2 interface under missing target velocity labels. Extending the same adaptation strategy to an audio-only velocity estimator remains a future direction.

**评价与推荐**：B 正面回答评审“是否也可以 audio→velocity”，并保留作者当前优先 S2 的立场。未采用作者口头“3 times MAE”：当前 Ch.4 Table4.2 的 hFT=9.9、Score-HPT=8.0 不能支持这个倍数。

**待核验／边界**：不新增 audio-only velocity 实验；Ch.4 global shift 的鲁棒性不等于 Ch.6 任意 onset error 无影响。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-07"></a>

## R1-07 Fig.2.1 是多种关系，不是必经 MIDI 的链

**操作**：修改 Figure2.1 caption；图副本增加 perceptual/audio → score dynamics 的虚线关系并注明 contextual inference，不改成固定换算。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_2/Background.tex` line 14

```latex
\begin{figure}[!htbp]
  \centering
  \includegraphics[width=0.9\linewidth]{Chapter_2/figures/dynamics_layers_v1.jpg}
  \caption{Layered view of dynamics used in this thesis. Physical sound level, perceived loudness, MIDI velocity, and score dynamics are linked but not interchangeable. Each transition is many-to-many or instrument-specific.}
  \label{fig:bg_dynamics_layers}
\end{figure}
```

`Chapter_2/Background.tex` line 26

```latex
This layered view has an important methodological consequence. There is no single exact lookup table that converts score dynamics, loudness, and MIDI velocity into one another. Nominal mappings are convenient for notation software and rendering systems, but they remain conventions. They should not be mistaken for measurement standards. This point is central to the whole dissertation because each chapter targets a different layer of the same broader expressive problem. Table~\ref{tab:bg_dynamics_compare} summarises the three dynamics representations that recur throughout this thesis, together with their temporal anchors, strengths, and limitations.
```

### A

Relationships among physical sound level, perceived loudness, MIDI velocity, and score dynamics. The layers are related but are not an obligatory processing chain. In particular, score dynamics may be inferred directly from audio-derived perceptual evidence without first estimating MIDI velocity; the inference remains context-dependent.

### B

Relationships among the dynamics representations used in this thesis. MIDI velocity is one route between symbolic control and sound, but it is not a required intermediate representation for score-dynamics estimation. Chapter 5 learns a direct audio-to-score-dynamics mapping. Instrument response, performer interpretation, and musical context prevent any of these links from defining a universal one-to-one conversion.

### C

The representations provide complementary descriptions of dynamics. Rendering relates MIDI velocity to acoustic output, psychoacoustic analysis relates audio to loudness, and contextual inference relates performed sound to score markings. The direct audio-to-score-dynamics route studied in Chapter 5 therefore coexists with velocity-based workflows; none supplies a fixed instrument-independent lookup table.

**评价与推荐**：B 同时保留作者强调的 instrument/style 不确定性并承认评审提出的直接路径，符合 Ch.5 实际输入输出。A 短；C 更像正文解释而非图注，可能变长。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-08"></a>

## R1-08 Bark 表每组三列加分隔线

**操作**：只在 Table2.3 的三组三列之间加线；这是格式提案，需最终排版核验。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_2/Background.tex` line 127

```latex
\begin{table*}[!htbp]
    \centering
    \caption{Approximate relation between critical-band rate in Bark and frequency in Hz. The full psychoacoustic scale spans 24 critical bands.}
    \label{tab:bark_table}
    \setlength{\tabcolsep}{4.6pt}
    \fontsize{11pt}{13pt}\selectfont
    \renewcommand{\arraystretch}{1.18}
    \begin{tabular}{ccc@{\hspace{8pt}}ccc@{\hspace{8pt}}ccc}
        \toprule
        \makecell[c]{\textbf{Critical}\\[1pt]\textbf{band rate}\\[1pt]\textbf{$z$ [Bark]}} &
        \makecell[c]{\textbf{Frequency}\\[1pt]\textbf{$f$ [Hz]}} &
        \makecell[c]{\textbf{$\Delta f$}\\[1pt]\textbf{[Hz]}} &
        \makecell[c]{\textbf{Critical}\\[1pt]\textbf{band rate}\\[1pt]\textbf{$z$ [Bark]}} &
        \makecell[c]{\textbf{Frequency}\\[1pt]\textbf{$f$ [Hz]}} &
        \makecell[c]{\textbf{$\Delta f$}\\[1pt]\textbf{[Hz]}} &
        \makecell[c]{\textbf{Critical}\\[1pt]\textbf{band rate}\\[1pt]\textbf{$z$ [Bark]}} &
        \makecell[c]{\textbf{Frequency}\\[1pt]\textbf{$f$ [Hz]}} &
        \makecell[c]{\textbf{$\Delta f$}\\[1pt]\textbf{[Hz]}} \\
        \midrule
        0 & 0    & 100 & 9  & 1080  & 190 & 18 & 4400  & 900  \\
        1 & 100  & 100 & 10 & 1270  & 210 & 19 & 5300  & 1100 \\
        2 & 200  & 100 & 11 & 1480  & 240 & 20 & 6400  & 1300 \\
        3 & 300  & 100 & 12 & 1720  & 280 & 21 & 7700  & 1800 \\
        4 & 400  & 110 & 13 & 2000  & 320 & 22 & 9500  & 2500 \\
        5 & 510  & 120 & 14 & 2320  & 380 & 23 & 12000 & 3500 \\
        6 & 630  & 140 & 15 & 2700  & 450 & 24 & 15500 & --   \\
        7 & 770  & 150 & 16 & 3150  & 550 &    &       &      \\
        8 & 920  & 160 & 17 & 3700  & 700 &    &       &      \\
        \bottomrule
    \end{tabular}
\end{table*}
A common analytic approximation from physical frequency $f$ in kHz to Bark rate $z$ is
\begin{equation}
z(f_{\mathrm{kHz}}) = 13\arctan(0.76 f_{\mathrm{kHz}}) + 3.5\arctan\!\left(\frac{f_{\mathrm{kHz}}^2}{7.5^2}\right),
\label{eq:bg:bark_mapping}
\end{equation}
where $f_{\mathrm{kHz}}$ denotes frequency in kHz \cite{pampalk2002content,pampalk2004exploring,zwicker1999psychoacoustics}. This equation defines the Bark coordinate itself. It does not yet compute loudness.
```

### A

\begin{tabular}{ccc|ccc|ccc}

**评价与推荐**：精确对应评审的 1–3 / 4–6 / 7–9，不误改 Table2.4 的软件映射表。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-09"></a>

## R1-09 把 onset 说法限定为本文的 Note On velocity

**操作**：替换 §2.3.2 第一段；可在 Ch.1 首次定义同步加入 Note On 限定。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_2/Background.tex` line 274

```latex
MIDI velocity is a different kind of representation. It is attached to a note onset rather than to a phrase or region. In conventional MIDI performance data, a sounding note onset carries a discrete velocity value on a finite integer scale. In a chord, each note may have a different velocity. In a rapid passage, every note can carry its own local attack value. MIDI velocity is therefore a micro-level representation: it serialises note-level actions rather than summarising the expressive state of a passage.
```

### A

In this thesis, MIDI velocity means the Note On velocity associated with a note attack. MIDI also supports Note Off velocity and separate control messages, which are not the targets studied here. Each sounding note can therefore receive its own onset-velocity value, including notes played simultaneously in a chord.

### B

The target studied here is MIDI Note On velocity: a discrete control value attached to the start of a note. This definition is narrower than the full MIDI protocol, which also includes Note Off velocity, aftertouch, and continuous controllers. The thesis estimates one onset value per note rather than a time-varying control trajectory.

### C

The note-level target in this thesis is Note On velocity. It records or controls the attack of an individual note, so simultaneous notes may have different values. Other MIDI messages can describe release behaviour or changes during a note, but these remain outside the present target. This is why the velocity chapters preserve note events and estimate only an onset attribute.

**评价与推荐**：作者确认 onset 的本意可保留，但全 MIDI protocol 的“always”需收窄。已向 MIDI Association 官方 message summary 核验 Note On、Note Off、aftertouch、CC 的区分；不新增未经同意的 bibliography 条目。A 最短；C 强调与 thesis 关系，略重。

**待核验／边界**：官方核验来源：https://midi.org/summary-of-midi-1-0-messages 。本段不讨论 velocity=0 的额外编码细节，避免引入与当前问题无关的规范内容。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-10"></a>

## R1-10 Fig.2.3 颜色不能猜含义

**操作**：推荐在图副本把 (d)–(f) note marks 改成单一颜色，保留 (g) 原有 grey/black/red metrical 编码；下列句子补入原 caption 的 (d)–(f) 描述后。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_2/Background.tex` line 442

```latex
\begin{figure}[!htbp]
  \centering
  \includegraphics[width=0.98\linewidth]{Chapter_2/figures/temporal_units}
  \caption[Aligned temporal coordinates across audio, symbolic, and metrical representations]{Aligned temporal representations for a 20\,s excerpt from MazurkaBL M33-4 (pid918726-08, 40--60\,s). Panels (a)--(c) show frame-level acoustic evidence: the log-Mel spectrogram, Bark-scale specific loudness (BSSL), and Bark-scale total loudness (BSTL). Panels (d)--(f) show note-level symbolic coordinates: note onsets, note-event spans, and a MIDI piano-roll visualisation. Panel (g) shows the metrical and phrase grid, with beats in grey, downbeats in black, and phrase boundaries in red. The figure illustrates how the same performance segment can be re-indexed from dense audio frames to note events and then to beat-, bar-, and phrase-level coordinates for dynamics recovery.}
  \label{fig:bg_temporal_units}
\end{figure}
```

### A

Panels (d)–(f) use a uniform colour for note events; colour does not encode velocity, voice, or instrument identity. Horizontal position indicates time. The vertical axes in (e) and (f) show the displayed event-lane index and MIDI pitch, respectively.

**评价与推荐**：现资产没有图例和作图脚本，不能从色相推断是 velocity 或 voice。统一颜色是可实施且不改变本图 temporal-coordinate 用途的最小方案。

**待核验／边界**：候选 caption 只在完成对应副本改图后可用。若保留现有颜色，必须先找到作图源确认编码并新增准确图例【待查】。已查看 main.pdf 物理页52／印刷页25，panel标题在白底PDF中正常显示；PNG工具黑区是透明背景预览，不能当论文排版缺陷。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-11"></a>

## R1-11 humanisation 用一行定义

**操作**：在 §2.5.1 首句后补定义。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_2/Background.tex` line 490

```latex
Expressive performance rendering aims to generate expressive control signals from symbolic input. Many systems predict timing, dynamics, and sometimes articulation jointly \cite{jeong2019virtuosonet,borovik2023scoreperformer}. These models are important because they show that expressive performance can be learned from symbolic structure. At the same time, they reveal a practical limitation for the present thesis. Joint expressive rendering may alter more than the user wants. In production or corpus-upgrading settings, the desired operation is often narrower: preserve the notes and timing, and recover only the missing dynamics layer. This narrower, controllable objective is the entry point for Chapter~\ref{ch:velcomp}.
```

### A

Here, humanisation refers to adding or varying expressive controls in a symbolic sequence, such as note timing and velocity, to move it away from a mechanically uniform rendering.

**评价与推荐**：无需删除已有术语；定义后马上回到本文只改 velocity 的范围，短句就能解决。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-12"></a>

## R1-12 crescendo 已有定义，只补定位与范围

**操作**：保留 §2.3.1 已有定义，在 §2.6.1 末补一个 cross-reference，避免重复一整段基础知识。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_2/Background.tex` line 263

```latex
Dynamic markings are the conventional score vocabulary for notated loudness and dynamic change. They include static markings such as \textit{pp}, \textit{p}, \textit{mp}, \textit{mf}, \textit{f}, and \textit{ff}, as well as directional indications such as \textit{crescendo}, \textit{diminuendo}, and hairpins. Although a marking is printed at a specific visual position, its musical scope is usually broader than that position. A single \textit{p} may govern a phrase, a texture, or a formal region until a later marking or musical event changes the dynamic state. A crescendo indicates a tendency over a span, not an isolated value at one note.
```

`Chapter_2/Background.tex` line 528

```latex
Computational modelling of dynamics has a long history in expressive performance research \cite{cancinoChacon2018computational}. Rather than focusing only on note-level control, this line of work studies how performed loudness relates to symbolic dynamic markings and phrase structure. Kosta and collaborators showed both the usefulness and the ambiguity of this relationship \cite{kosta2014dynpiano,kosta2016mapping,kosta2018mazurkabl}. Other work has further analysed dynamic principles in piano performance \cite{jones2023probingdyn}.
```

### A

Besides static levels, score dynamics includes gradual indications such as crescendo and diminuendo, as described in Section 2.3.1. Chapter 5 estimates the five static levels available in its annotations and their change points; it does not explicitly decode these longer-span symbols.

**评价与推荐**：原文 §2.3.1 已明确 directional indications、hairpins 和 span。真正缺口是 §2.6.1 与 Ch.5 实验范围衔接；未来方向另见 R1-38。

**合并关系**：R1-38。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-13"></a>

## R1-13 数据表拆清 note events、performance velocity、score 与音频可用性

**操作**：各稿给出完整 caption/notes 提案；不自动重写数据值。A 改表头和注，B 加 audio 列须逐行核验，C 把模态解释移至表后。

**独立审查处理**：接受。修B的provenance措辞及C遗漏图例；保留A作为最小方案。

**对应finding**：F04。

**实际原文与定位**

`Chapter_2/Background.tex` line 594

```latex
The empirical claims of this thesis are conditioned on what each available dataset can support. Table~\ref{tab:dataset_comparison} summarises the representative corpora relevant to expressive label recovery, listing their instrument coverage, scale, and which expressive modalities (MIDI velocity, score, and score dynamics) are actually available. The MIDI column also includes note annotations that can be converted to MIDI, such as the JAMS annotations in GuitarSet. The discussion that follows turns these modality differences into chapter-specific constraints.
```

`Chapter_2/Background.tex` line 596

```latex
\begin{table}[!htbp]
\centering
\caption{Representative datasets relevant to expressive label recovery in this thesis. Each dataset is summarised by its instrument family, scale, and the expressive modalities (MIDI, velocity, score, score dynamics) it provides.}
\label{tab:dataset_comparison}
```

### A

Representative datasets relevant to expressive label recovery. “MIDI / note annotations” includes performance MIDI and aligned note annotations convertible to MIDI; it does not by itself imply measured velocity. “Velocity” indicates the availability of the note-level dynamics target, with qualifications stated in the row notes. “Score” refers to a reference symbolic score, rather than the performance timing in MIDI. A triangle marks a qualification in the corresponding row. For ATEPP, 43% denotes the reported share of recordings paired with scores, not a verified share with score-dynamics labels. Audio access limitations are stated separately in the row notes.

### B

Representative datasets relevant to expressive label recovery, separating audio access, note annotations, velocity annotations, reference scores, and score-dynamics annotations. The provenance of velocity annotations is specified in the row notes. A tick indicates the stated modality, a cross indicates its absence, and a triangle refers to a qualification in the corresponding row note. The audio column distinguishes available performance recordings, externally linked recordings, and software-rendered material. For ATEPP, the reported 43% applies to score availability; the dynamic markings in those scores have not been verified.

### C

The table separates structural note information from expressive supervision. A MIDI file or a convertible note annotation can provide pitch and timing without containing measured performance velocity. Reference scores provide notated structure and may be quantised, whereas performance MIDI retains performed timing. The 43% shown for ATEPP describes score coverage and should not be read as the availability of verified dynamic markings. Audio access and any annotation qualifications remain dataset-specific and are stated in the row notes. A triangle indicates a qualification explained in the corresponding row note.

**评价与推荐**：推荐A：只补字段释义和图例，最少改变拥挤表格。B已改成velocity annotations并要求row notes写provenance，不把estimated/software/captured混称captured；但新增Audio单元格仍待逐行填实。C已补triangle通用图例，可作表后解释。ATEPP分母仍是待确认项。

**待核验／边界**：【待确认 ATEPP 数据版本及43%分母】；B 的 audio 列只可用原资料逐行填，特别 MID-FiLD 必须区分软件制作／rendered 与 human recording，不能凭列名全打勾。不触碰已修正 MAESTRO/MAPS 数字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-14"></a>

## R1-14 背景定义常用指标，同时保留 Ch.5 平均方式待核验

**操作**：在 §2.8.3 首段后插入；A 最短，B 给公式，C 给读者如何读各指标的衔接。

**独立审查处理**：接受。A加class/event-type限定；C不再保证当前有冲突的定义已对应每个结果。B定义稿保持。

**对应finding**：F05。

**实际原文与定位**

`Chapter_2/Background.tex` line 886

```latex
Score dynamics is usually evaluated as classification on a musically meaningful grid. F1 score is common because the class distribution is imbalanced and because some symbols occur much less frequently than others \cite{kosta2017thesis}. In the present thesis, beat-synchronous evaluation is especially important because it avoids arbitrary frame-level tolerance choices and aligns the prediction target with how the annotations are actually used in music notation.
```

`Chapter_2/Background.tex` line 879

```latex
Velocity should be evaluated at note level rather than by naive frame-wise error. Otherwise, long sustained notes dominate the metric. Standard statistics include mean absolute error and related dispersion measures \cite{kuo2021velocity,kim2024method}. However, numerical accuracy alone is not sufficient. A model can achieve a decent average error while producing over-smoothed or mechanically centred dynamics. Distribution-sensitive measures, visual inspection, and listening tests therefore play an important complementary role. This is especially evident in Chapter~\ref{ch:velcomp}, where perceptual differences are not always fully captured by raw error.
```

### A

For a given class or event type, precision is the fraction of predictions that are correct, and recall is the fraction of reference instances that are recovered. Their harmonic mean is F1. For note-level velocity, MAE measures the mean absolute difference from the reference value; Chapter 3 additionally reports error dispersion, tolerance-based recall, and predicted-velocity dispersion. Each metric is interpreted on the coordinate appropriate to its target.

### B

For a given class or event type, precision is TP/(TP+FP), recall is TP/(TP+FN), and F1 is 2TP/(2TP+FP+FN), where TP, FP, and FN are true positives, false positives, and false negatives. Macro-F1 averages the class-wise scores equally, whereas support-weighted F1 weights them by their reference counts. These averages answer different questions and must be identified when reporting score-dynamics results. Note-level velocity MAE averages the absolute prediction error over the reference note onsets; its full definition and the complementary dispersion metrics are given in Section 3.6.3.

### C

Evaluation follows the output representation. Note-wise velocity error measures agreement with captured MIDI values, while velocity dispersion checks whether the output collapses towards a constant. Score dynamics is assessed as beat-wise classification, for which precision, recall, and F1 describe false labels and missed labels. Beats and downbeats are evaluated as time-stamped events. The averaging rule, temporal grid, and event-matching tolerance must be identified when interpreting each result.

**评价与推荐**：B 正式区分 macro 与 weighted，能补齐 background，又不擅自断言现有 Ch.5 数值是哪一种。A 更短但数学定义略弱；C 适合读者导向，缺明确定义。Chapter3 metrics 实际 §3.6.3，最终自动引用 label 应取代硬编码编号。

**待核验／边界**：V-05：Ch.5 公式写 macro，固定 evaluator 写 weighted；未确认实际论文 run。不得把此背景定义当作已解决运行来源。公式采用通用定义，空分母规则留给实现核验。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-15"></a>

## R1-15 用信息条件描述 S1，不用单一难度排序

**操作**：替换 Ch.3 §3.1 首段整体。下列A/B/C均已完整拼接，后面的应用段保持原样；同步位置仍按各自准确原句局部替换。

**独立审查处理**：接受拼接问题。改为展示完整首段；保留三种velocity缺失/简化状态。A采用单独审读者建议的简短首句，B/C按全段语境重写。

**对应finding**：F01。

**实际原文与定位**

`Chapter_3/chap3.tex` line 13

```latex
This chapter addresses Scenario~S1, the most controlled setting in the thesis map. Here the symbolic notes and their timing are already known, but the note-level velocity is missing, flattened, or musically uninformative. The chapter therefore asks a focused question: can useful note-level dynamics be recovered from symbolic structure alone, without changing the original composition?
```

`Chapter_7/Conclusion.tex` line 48

```latex
The first method contribution establishes the most controlled setting: the symbolic note sequence is fixed, and only the missing MIDI velocity layer is restored. Chapter~\ref{ch:velcomp} reformulates this task as image colourisation on sparse piano-roll matrices. This is not only an architectural analogy. Polyphonic symbolic music contains local pitch--time neighbourhoods and vertical chordal patterns that are weakened when the task is treated as a plain sequence. A U-Net with window attention and a sparsity-aware loss can exploit this structure while leaving the underlying note content unchanged.
```

### A

This chapter addresses Scenario S1, where only symbolic information is available. Here the symbolic notes and their timing are already known, but the note-level velocity is missing, flattened, or musically uninformative. The chapter therefore asks a focused question: can useful note-level dynamics be recovered from symbolic structure alone, without changing the original composition?

### B

This chapter addresses Scenario S1, where the symbolic notes and their timing are known, but the velocity layer is missing, flattened, or musically uninformative. No performance audio is available to guide the prediction. The fixed note structure limits what the model may change without uniquely determining the velocity profile. The chapter therefore asks a focused question: can useful note-level dynamics be recovered from symbolic structure alone, without changing the original composition?

### C

In the symbolic-only setting, the notes and their timing are fixed, while velocities may be missing, flattened, or musically uninformative. The model changes only the velocity layer and has no performance audio from which to infer it. The chapter therefore asks a focused question: can useful note-level dynamics be recovered from symbolic structure alone, without changing the original composition?

**随后保留的上下文**

This setting matters because it isolates the dynamics problem from the broader transcription problem. It is common in digital audio workstation workflows, step-entered MIDI, quantised MIDI, and corpus curation settings where note content already exists but expression does not. It also provides the cleanest test of the thesis claim that dynamics can be treated as a separate and editable target rather than as a side effect of full expressive performance generation.

**评价与推荐**：A只替原首句，完整保留原来的第二、三句，最接近作者原段；B进一步区分固定结构和估计歧义；C把条件与模型操作连起来，稍有改写。推荐A作为最小有效修改，B供作者希望把歧义讲明时选择。三稿均不再把候选首句叠加到重复的原第二句。

**逐句同步提案**

- `Chapter_3/chap3.tex` line 31
  - 原：This chapter studies the most constrained setting in that map:
  - 拟：This chapter studies the symbolic-only setting in that map:

- `Chapter_3/chap3.tex` line 465
  - 原：This chapter studied the most controlled form of expressive-label recovery:
  - 拟：This chapter studied expressive-label recovery without acoustic input:

- `Chapter_7/Conclusion.tex` line 48
  - 原：The first method contribution establishes the most controlled setting:
  - 拟：The first method contribution addresses the symbolic-only setting:

- `Chapter_1/Intro.tex` line 118
  - 原：By intentionally ordering these environments from the tightly constrained to the ambiguous, they form the core empirical arc of the thesis.
  - 拟：These settings form the core empirical arc of the thesis by varying both the available evidence and the target representation.

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-16"></a>

## R1-16 区分跨曲目使用与风格控制

**操作**：在 Ch.3 Discussion 的 empirical-scope 段后插入。

**独立审查处理**：接受相邻限制去重。这里保留style-conditioning任务说明，把人数/片段/单renderer和非因果分组解释留在听测Results。

**对应finding**：F15。

**实际原文与定位**

`Chapter_3/chap3.tex` line 459

```latex
The empirical scope of the chapter is piano-based, using datasets recorded with Yamaha Disklavier instruments.
Within that scope, the cross-dataset MAESTRO-to-SMD results show that the image-colourisation formulation is not merely memorising one corpus.
```

`Chapter_3/chap3.tex` line 444

```latex
\paragraph{Results.}
Although a substantial gap to human performance remains, the proposed U-Net clearly outperforms the other systems.
The Flat model performs worst, consistent with earlier findings that default velocity is musically inadequate \cite{kuo2021velocity}.
The seen, less-seen, and unseen repertoire groups are best interpreted as descriptive groups rather than as a strict complexity-controlled comparison.
Even so, the relatively narrow 95\% confidence intervals across groups suggest that participants rated the stimuli with reasonable consistency.
```

### A

The model is not conditioned on composer or performer identity. Its aim is to provide a useful velocity completion across the piano repertoire represented in the data, rather than to reproduce a requested style.

### B

Composer and performance style can influence a plausible velocity profile, but the present model does not offer explicit style control. The available training data motivated learning a shared completion model rather than separate composer-specific models.

### C

A completed velocity profile is one plausible expressive interpretation of a fixed note sequence. The present model learns this interpretation from pooled piano performances without a composer or style control input. The composer-group scores reported in the listening section describe the model within the selected repertoire.

**评价与推荐**：B保留作者因数据覆盖限制选择shared completion的解释。A最短；C强调多解性，但与R1-19可能重复。听测样本和composer分组限制集中在R2-04，不在这里再加一遍。

**待核验／边界**：不能把 two unseen composers 或MOS差异写成因果性 composer effect，也不声称模型已 generalise to any style。

**合并关系**：R1-19; R2-04。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-17"></a>

## R1-17 image-like 的含义与 piano-roll 选择一起解释

**操作**：在 Ch.3 §3.2 只替换原image-based动机段。保留发表题名、章名、已有image-like标题以及其他已能按analogy理解的colourisation表述；下方逐处表给出准确原句与保留理由。与R1-18共享此段，不重复插入。

**独立审查处理**：接受。把模糊全文替词指令改为12处准确出现点的保留/替换审计；仅§3.2段落真正提出replacement。

**对应finding**：F10。

**实际原文与定位**

`Chapter_3/chap3.tex` line 26

```latex
This motivates the image-based view adopted in the present chapter. By treating symbolic MIDI as a sparse image and velocity as a colourisation target, the model can exploit local polyphonic structure more directly. U-Net and attention mechanisms are already successful in related music and audio tasks, but the present setting is distinct because it is purely symbolic and does not rely on acoustic input \cite{he2025filling,kim2024method}. This makes the chapter a natural starting point for the broader thesis.
```

`Chapter_3/chap3.tex` line 43

```latex
This chapter instead exploits the spatial structure of polyphonic symbolic music by treating MIDI as an image-colourisation problem. MIDI without velocity is represented as a binary pianoroll, while the target is a velocity-valued pianoroll. This formulation is especially natural for instruments such as piano, where multiple simultaneous notes create rich vertical patterns. Current dataset availability restricts the experiments here to piano data, but the formulation itself is not tied to piano alone.
```

### A

The representation is image-like because pitch and time form a two-dimensional grid processed by convolutional layers. The binary piano roll provides the note structure, and the target velocity roll assigns a scalar value at note locations. Colourisation is an analogy for adding the missing velocity layer; the model does not predict RGB colours. This representation motivates the U-Net and attention design used here \cite{he2025filling,kim2024method}.

### B

A piano roll places simultaneous notes along the pitch axis and their local evolution along time, giving the U-Net a regular two-dimensional input. Convolution and skip connections can then use local pitch–time neighbourhoods while preserving the given note structure. The output is a single-channel velocity roll. We use colourisation as an analogy for completing that missing scalar layer, rather than for predicting RGB colour. This representation motivates the U-Net and attention design used here \cite{he2025filling,kim2024method}.

### C

The choice of representation follows the proposed architecture. A piano roll exposes local pitch–time neighbourhoods and simultaneous-note patterns on a regular grid that can be processed by a U-Net. Note-list or event-token representations are valid alternatives, but would require a different interface. The image-like formulation studied here adds a single velocity channel to existing notes; its advantages over the selected baselines do not establish that it is superior to every event-based formulation. This representation motivates the U-Net and attention design used here \cite{he2025filling,kim2024method}.

**评价与推荐**：推荐B，局部澄清single-channel与regular pitch-time grid，并保留原段已有citation keys。R1-18共用。全文只出现这一处image-based需要改；其他colourisation用法可以保留为已定义的analogy，不能机械改正式title或每处都补RGB解释。具体审计只证明完成逐句检查，不宣称源文已修改或最终全文一致性已执行。

**待核验／边界**：V-03：当前源码写 F input；固定训练快照配置 onset_mask=True 且默认 matrix channels=2，不能直接证明论文run。此段只解释表示，不重复确定未经核验的实际输入分支。

**合并关系**：R1-18。不重复实施共享文字。

**准确术语出现点与处理**（仅列实际源文，不作概括性替词）

`main.tex` line 138

```latex
The thesis first addresses the symbolic-only setting by reformulating MIDI velocity completion as image colourisation on sparse piano-roll matrices. A U-Net with window attention and a sparsity-aware loss recovers the missing velocity layer, and the results are validated through cross-dataset objective metrics and a MUSHRA-inspired listening test.
```

处理：保留首句colourisation类比；同段validated→assessed由R2-04单独处理，不重复补RGB。

`Chapter_1/Intro.tex` line 164

```latex
\item \textbf{A symbolic method for note-level velocity completion (Addressing S1).} It reformulates MIDI velocity completion as an image-colourisation problem on sparse piano-roll representations, introducing a U-Net architecture with window attention and a sparsity-aware loss \cite{he2025filling}.
```

处理：保留；按本项新增定义读为single-channel完成类比，现句不声称RGB；不重复解释。

`Chapter_3/chap3.tex` line 6

```latex
\chapter{Symbolic MIDI Velocity Completion as Image Colourisation}
```

处理：保留原题名／现有image-like标题，不改正式名称。

`Chapter_3/chap3.tex` line 17

```latex
This chapter makes three contributions. First, it shows that symbolic velocity completion can be formulated naturally as an image-colourisation problem on sparse piano-roll representations. Second, it develops a U-Net-based model with window attention and a sparsity-aware loss tailored to this representation. Third, it provides both objective and perceptual evidence that recovering only MIDI velocity can improve musical expressiveness in a controlled setting.
```

处理：保留；按本项新增定义读为single-channel完成类比，现句不声称RGB；不重复解释。

`Chapter_3/chap3.tex` line 26

```latex
This motivates the image-based view adopted in the present chapter. By treating symbolic MIDI as a sparse image and velocity as a colourisation target, the model can exploit local polyphonic structure more directly. U-Net and attention mechanisms are already successful in related music and audio tasks, but the present setting is distinct because it is purely symbolic and does not rely on acoustic input \cite{he2025filling,kim2024method}. This makes the chapter a natural starting point for the broader thesis.
```

处理：替换整段为本项所选A/B/C；准确replacement见上文。

`Chapter_3/chap3.tex` line 43

```latex
This chapter instead exploits the spatial structure of polyphonic symbolic music by treating MIDI as an image-colourisation problem. MIDI without velocity is represented as a binary pianoroll, while the target is a velocity-valued pianoroll. This formulation is especially natural for instruments such as piano, where multiple simultaneous notes create rich vertical patterns. Current dataset availability restricts the experiments here to piano data, but the formulation itself is not tied to piano alone.
```

处理：保留；按本项新增定义读为single-channel完成类比，现句不声称RGB；不重复解释。

`Chapter_3/chap3.tex` line 45

```latex
\section{Representation as Image-like MIDI Matrices}
```

处理：保留原题名／现有image-like标题，不改正式名称。

`Chapter_3/chap3.tex` line 92

```latex
For upsampling, we use transpose convolutions with \(4 \times 4\) kernels and stride 2, following the image-colourisation variant in \cite{wang2022cunet}.
```

处理：保留；这是所引图像colourisation架构来源，不是把MIDI输出说成RGB。

`Chapter_3/chap3.tex` line 455

```latex
The image-colourisation view is effective because it matches the structure of the data. Polyphonic note patterns create meaningful vertical and local spatial regularities that are awkward to express in purely sequential terms. The U-Net captures this local structure well, and the sparsity-aware loss prevents the model from spending most of its capacity on silent regions. The results suggest that this representation choice is a major reason the method surpasses the sequence-based baselines considered here.
```

处理：保留；按本项新增定义读为single-channel完成类比，现句不声称RGB；不重复解释。

`Chapter_3/chap3.tex` line 460

```latex
Within that scope, the cross-dataset MAESTRO-to-SMD results show that the image-colourisation formulation is not merely memorising one corpus.
```

处理：保留；按本项新增定义读为single-channel完成类比，现句不声称RGB；不重复解释。

`Chapter_3/chap3.tex` line 465

```latex
This chapter studied the most controlled form of expressive-label recovery: the notes, onsets, and offsets are already fixed, and only the missing MIDI velocity layer is inferred. By casting the piano roll as an image-like representation, the proposed U-Net uses local pitch--time neighbourhoods and vertical chordal patterns that are weakened in a purely sequential formulation. Window attention and an onset-masked, velocity-aware loss are not incidental additions; they match the sparse structure of the target and prevent the model from optimising mainly around silence.
```

处理：保留；按本项新增定义读为single-channel完成类比，现句不声称RGB；不重复解释。

`Chapter_7/Conclusion.tex` line 48

```latex
The first method contribution establishes the most controlled setting: the symbolic note sequence is fixed, and only the missing MIDI velocity layer is restored. Chapter~\ref{ch:velcomp} reformulates this task as image colourisation on sparse piano-roll matrices. This is not only an architectural analogy. Polyphonic symbolic music contains local pitch--time neighbourhoods and vertical chordal patterns that are weakened when the task is treated as a plain sequence. A U-Net with window attention and a sparsity-aware loss can exploit this structure while leaving the underlying note content unchanged.
```

处理：保留colourisation类比和后续方法说明；most controlled首句由R1-15局部替换。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-18"></a>

## R1-18 piano roll 与 event list 的取舍

**操作**：与 R1-17 共用同一段，不重复插入。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_3/chap3.tex` line 43

```latex
This chapter instead exploits the spatial structure of polyphonic symbolic music by treating MIDI as an image-colourisation problem. MIDI without velocity is represented as a binary pianoroll, while the target is a velocity-valued pianoroll. This formulation is especially natural for instruments such as piano, where multiple simultaneous notes create rich vertical patterns. Current dataset availability restricts the experiments here to piano data, but the formulation itself is not tied to piano alone.
```

### A

Use the selected paragraph under R1-17. It explains the regular pitch–time grid and limits the comparison to the representations actually studied.

**评价与推荐**：两个问题紧邻且共享解释；一段即可覆盖，另在 representation 开头保留 O/F/V 数学定义。

**合并关系**：R1-17。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-19"></a>

## R1-19 recovery 是实验构造，estimation 是一般任务

**操作**：在 §3.3 问题设定末补一段。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_3/chap3.tex` line 31

```latex
MIDI (Musical Instrument Digital Interface) is the dominant symbolic format in modern music production. A MIDI file that resembles sheet music can still sound mechanical when its note velocities are undefined or flattened to a default constant. In contrast, MIDI captured from human performance preserves the performer's control of intensity and therefore carries a substantial portion of the perceived musical expression. As discussed in the thesis introduction, dynamics is the expressive dimension targeted first in this thesis because it is both perceptually salient and directly editable. This chapter studies the most constrained setting in that map: recovering note-level MIDI velocity when the symbolic notes and their timing are already known.
```

### A

Velocity completion is an estimation task. In the supervised experiments, reference velocities are removed from captured performances, so recovery describes the reconstruction setting. At deployment, a sequence with flat or missing velocities may admit several plausible completions; the model does not recover a uniquely determined original performance from note structure alone.

### B

We use completion for the operation of adding missing velocities and estimation for the prediction problem. Recovery is appropriate in the supervised evaluation because the withheld reference values are known. For new symbolic input, the output is instead an estimated expressive profile, whose usefulness need not imply that it reproduces one uniquely correct interpretation.

### C

The training construction begins with performance MIDI and withholds its velocity layer. This permits a direct comparison against captured values, but does not make velocity a deterministic function of the score. The same estimator can complete previously unseen or quantised MIDI without a recorded reference; in that use, its output should be read as a plausible velocity realisation rather than a reconstruction of a known performer.

**评价与推荐**：B 保留作者“开始是recovery，最终task是estimation”，不强迫全论文统一成一个词。A 很直接；C 衔接应用好，但与 R1-21 可能重复。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-20"></a>

## R1-20 physical time 是兼容性选择，不是 beat-alignment 劣势的证明

**操作**：在 §3.4.2 segmentation 结果后插入；同时将“10s roughly four measures at120 BPM”改为“several bars, depending on tempo and metre”。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_3/chap3.tex` line 61

```latex
The segment duration is a key design variable in this formulation.
Because a MIDI performance often exceeds three minutes, we split each piece into shorter segments to keep the computation tractable.
The number of time frames \(T\) determines the temporal granularity of the matrix representation, so the timestep resolution is
\begin{equation}
\text{Resolution} = \frac{\text{Segment Duration}}{T}.
\label{eq:velcomp_resolution}
\end{equation}
Unlike tasks that require fine temporal resolution to detect unknown note events, the present task already assumes that note timing is given.
This makes a more computationally efficient timestep resolution feasible.
With a fixed input size of \(T=96\), we explored segment durations of 5 s, 10 s, 15 s, and 20 s in hyperparameter search and found that 10 s yielded the best results.
A plausible explanation is that a 10-second window often captures a musically coherent phrase, for example roughly four measures at 120 BPM, providing enough context without overextending the receptive field.
```

### A

The fixed-duration representation accepts the note timings already present in a MIDI file, including performance MIDI and estimated note events, without requiring a beat map. A musical-time representation is also possible, but is not compared in the present experiments.

### B

We use physical time to retain the timing supplied with the input and to avoid requiring a score or beat map. This is useful when the input comes from a performance or a transcription system as well as from a quantised score. A beat-relative representation could provide useful metrical context; the present study does not establish whether it would improve velocity estimation.

### C

Physical-time and musical-time grids emphasise different information. The current grid accepts existing event times directly, while a beat-relative grid could normalise tempo and expose metrical position. Such a representation need not remove expressive timing if that information is retained separately. We therefore treat the choice as an untested representation alternative, rather than claim that beat alignment would necessarily reduce expressiveness.

**评价与推荐**：B 保留作者兼容 AMT 输入的实际动机，但不把 beat-relative 等同 hard quantisation。C 更直接纠正逻辑，语气稍像回复而非正文；A 最小。

**待核验／边界**：这里只改说明，不增加实验。10s=4 measures 的解释本来取决于 metre/tempo；4/4在120BPM的4小节是8s。

**逐句同步提案**

- `Chapter_3/chap3.tex` line 71
  - 原：roughly four measures at 120 BPM
  - 拟：several bars, depending on tempo and metre

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-21"></a>

## R1-21 量化 MIDI 听测保留作者说明，待刺激记录对齐

**操作**：在 Ch.3 Discussion 的首段后插入一段应用说明，原 Stimuli 协议暂不替换。下列A/B/C只写已知训练来源与接口用途；量化预处理字段放在候选之外。

**独立审查处理**：接受。把可用的thesis应用段与协议工作状态分开；原三种带内部说明的稿不再作为可粘贴正文。

**对应finding**：F02。

**实际原文与定位**

`Chapter_3/chap3.tex` line 375

```latex
\paragraph{Stimuli.}
The test used eight 10-second MIDI segments, each selected from one of the SMD performances listed in Table~\ref{tab:velcomp_composers}.
For each segment, the original human-performed velocities were removed to create a common symbolic input.
The Flat, ConvAE, and U-Net outputs were then rendered as stimuli, while the original MIDI with human-performed velocity served as the reference.
All stimuli were rendered with the PianoTeq~8 plug-in using the Steinway Model D instrument.
```

`Chapter_3/chap3.tex` line 453

```latex
This chapter has verified that note-level dynamics can be recovered usefully even when the symbolic notes and timing are held fixed. It turns expressive enhancement into a controllable post-processing stage rather than a full performance-rendering problem, which is exactly the setting encountered in many MIDI-production and corpus-curation workflows.
```

**拼接时先保留的上段**

This chapter has verified that note-level dynamics can be recovered usefully even when the symbolic notes and timing are held fixed. It turns expressive enhancement into a controllable post-processing stage rather than a full performance-rendering problem, which is exactly the setting encountered in many MIDI-production and corpus-curation workflows.

保留上方Discussion原首段，再换段插入所选A/B/C；随后接R1-17所对应的表示讨论。Stimuli原文仍列为未定，不把SMD来源自动解释成performance-timed或quantised。

### A

Performance MIDI supplies captured velocity targets for training, while the completion interface can also accept quantised symbolic input. The composition use case is to add a velocity profile while retaining the notes and timing supplied by the user.

### B

The supervised experiments use performance MIDI because it provides captured velocity targets. The completion interface itself takes the note events and timing supplied with a MIDI sequence, including quantised symbolic input. Its role in composition is to add a velocity profile without changing that supplied structure.

### C

For composition, velocity completion adds an expressive layer to an existing note sequence. Training uses captured velocities from performance MIDI, while deployment can retain the notes and timing of quantised symbolic input. The training target and the timing representation of a new input therefore serve different roles.

**评价与推荐**：A最短且足以说明训练数据和composition接口不冲突；B更明确区分训练与输入条件；C叙述较顺。三稿均不含“The author reports”、编辑指令或虚构的timing处理。推荐A。

**待核验／边界**：V-02仍待核验。作者当前原批注明确说量化MOS；正文只交代SMD来源与去velocity，缺具体timing preparation。待查字段：输入量化步骤、grid/分辨率、是否改duration、reference采用何种timing、是否各系统共用处理。没有证据前不写任一确定协议，也不默认reference与input做了同样量化。此处不要求新实验。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-22"></a>

## R1-22 单列 baselines，重排已有事实即可

**操作**：在 Experimental Setup 新增 Baselines 小节，将 Quantitative Results 已有说明移入；以下为完整可用段落，原处不重复。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_3/chap3.tex` line 241

```latex
Tables~\ref{tab:velcomp_results_smd} and \ref{tab:velcomp_results_maestro} report the model performance when all trainable systems are trained only on the MAESTRO training set.
The Flat model assigns a fixed velocity of 64, corresponding to the default behaviour of common music software.
The Seq2Seq baseline uses pretrained weights from \cite{kim2023piano}, while ConvAE \cite{kuo2021velocity} is re-implemented and trained within the same framework.
Across both test conditions, the proposed U-Net outperforms the comparison systems on all reported objective metrics.
```

`Chapter_3/chap3.tex` line 194

```latex
The trained models include the proposed U-Net and a re-implemented ConvAE baseline \cite{kuo2021velocity}.
Continuous segments from the same piece are arranged into the same batch in the training setup used here, with the aim of preserving local musical continuity.
Both models are trained for 300 epochs on the MAESTRO training set with learning rate \(10^{-5}\), batch size 3, and the same loss function.
Training takes approximately 12 hours on an NVIDIA V100 32~GiB GPU using the Ranger21 optimiser.
The top three checkpoints of each model, selected by validation performance on MAESTRO, are then tested on the MAESTRO test split and on SMD for cross-dataset evaluation.
```

### A

We compare against three baselines. Flat assigns velocity 64 to every note and represents a sequence without note-wise dynamic variation. Seq2Seq uses the pretrained attention-based model of Kim et al. (2023). ConvAE follows Kuo et al. (2021) and is re-implemented in our training framework. ConvAE and the proposed U-Net are trained on the same MAESTRO split with the same training schedule and objective; Seq2Seq retains its available pretrained weights. All outputs are evaluated at the given note onsets using the metrics defined below.

**评价与推荐**：无需新增网络细节或未经核验的parametercounts。既有引用键 kim2023piano / kuo2021velocity 应用于此段，英文作者年仅为阅读写法，排版沿作者最终citation选择。

**待核验／边界**：V-03 涉及ConvAE和U-Net实际输入mask分支：如强调“完全相同input”需run记录；本段只说已写明的训练schedule/objective。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-23"></a>

## R1-23 modular correction 的实际适用范围与联合模型互补

**操作**：在 §4.4 末补一段；不改变训练或模型。

**独立审查处理**：三稿均通过；接受独立审查的编辑偏好，推荐改为A，英文保持原稿。

**实际原文与定位**

`Chapter_4/chap4.tex` line 50

```latex
This separation of roles is important. The acoustic branch still provides the initial evidence for performance intensity. The score does not overwrite that evidence. Instead, it regularises the estimate by telling the model where notes occur and how they are organised in time. Later results will show that this division of labour is strong enough to improve both in-domain accuracy and cross-dataset behaviour.
```

### A

This modular setting is useful when trusted note events already exist, as in aligned educational or archival material. It does not imply that velocity and note detection are independent in performance, or that joint modelling cannot improve transcription. The present evaluation isolates velocity estimation at known notes and therefore does not measure gains in note detection.

### B

The separation is a task definition rather than a claim that note content and dynamics are independent. It fits applications with a reliable score or existing note sequence, where replacing note decisions is unnecessary. Joint note-and-velocity models may use these quantities to support one another, but that benefit is outside an evaluation that supplies reference note events. The contribution here is a reusable refinement interface under this stated condition.

### C

Modular refinement and joint transcription address different use conditions. If a reliable note sequence is available, a velocity-only correction can improve its expressive layer while preserving the user's structure. If the note sequence is uncertain, a joint system may be more appropriate because dynamics and note evidence can interact. This chapter studies the first condition and leaves the second as an integration direction.

**评价与推荐**：独立审查认为A已能说明应用范围和未测note-detection增益，且§4.4已有较充分用例说明。本轮采用A作为最小方案；B/C保留供作者偏好更完整局部讨论时选择，不再机械推荐最长稿。

**待核验／边界**：“backbone unchanged”应指architecture/interface；当前训练写 jointly trained，Background写frozen需 V-04 核验，不能据此给全网络冻结承诺。

**合并关系**：R1-27; R1-37。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-24"></a>

## R1-24 Ch.4 实际上是矩阵接口加 onset tokens

**操作**：在 §4.5.1 定义 O/F/Fex 后补充；这属于事实性解释，给一稿。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_4/chap4.tex` line 67

```latex
Consistent with the standard paradigm of score-informed MIDI velocity estimation \cite{kim2024method}, we rasterise the aligned score into pianoroll-like binary matrices at the same time resolution as the AMT output. Let $T$ be the number of frames and $P$ the number of piano keys. In our setting, $T=1001$ and $P=88$. We define the onset matrix $\mathbf{O}\in\{0,1\}^{T\times P}$, the frame matrix $\mathbf{F}\in\{0,1\}^{T\times P}$, and the onset-excluded sustain matrix $\mathbf{F}^{\mathrm{ex}}\in\{0,1\}^{T\times P}$ as
\begin{equation}
\mathbf{F}^{\mathrm{ex}} = \mathbf{F} - \mathbf{O}.
\label{eq:scoreinf:fex}
\end{equation}
We further define the nonzero index sets
\begin{equation}
\mathcal{I} = \{(t,p)\mid O_{t,p}=1\},
\qquad
\mathcal{J} = \{(t,p)\mid F_{t,p}=1\}.
\label{eq:scoreinf:index}
\end{equation}
The onset set $\mathcal{I}$ is used for tokenisation in the Transformer correction module. The frame set $\mathcal{J}$ is used for loss masking.
```

`Chapter_4/chap4.tex` line 106

```latex
\textbf{Final design: score-informed Transformer correction module.} Our final design replaces the frame-wise BiLSTM with an onset-token Transformer correction module. For computational efficiency, we tokenise only the score onset coordinates in $\mathcal{I}$. This yields a variable-length sequence of $N=|\mathcal{I}|$ tokens per segment. For each onset token $i=(t_i,p_i)\in\mathcal{I}$, we form an embedding
\begin{equation}
\mathbf{x}_i = \mathbf{e}^{(t)}_{t_i} + \mathbf{e}^{(p)}_{p_i} + \mathbf{W}_f\mathbf{f}_i,
\label{eq:scoreinf:token}
\end{equation}
where $\mathbf{e}^{(t)}_{t_i}$ and $\mathbf{e}^{(p)}_{p_i}$ are learnable time and pitch embeddings. The feature vector $\mathbf{f}_i$ contains the onset-wise preliminary velocity $\hat{V}_{0,t_i,p_i}$ together with optional score-derived features from $\mathbf{F}$ or $\mathbf{F}^{\mathrm{ex}}$, projected by $\mathbf{W}_f$. Stacking all embeddings yields $\mathbf{X}\in\mathbb{R}^{N\times d}$. This sequence is processed by a lightweight Transformer encoder implemented as a streamlined Conformer-like block~\cite{gulati2020conformer}, as shown in Figure~\ref{fig:scoreinf_encoder}.
```

### A

The matrices provide a common pitch–time interface with the AMT velocity map and make onset and sustain masking explicit. They are not the final sequence representation of the Transformer: the correction module extracts the known onset coordinates and processes them as note tokens. The frame-wise BiLSTM variant retains the dense grid for comparison. The final design therefore combines a piano-roll interface with event-centred correction rather than choosing dense matrices over event tokens throughout.

**评价与推荐**：作者批注提到multi-scale，但本章最终模块是onset-tokenTransformer；不能把Ch.5架构动机借来当Ch.4事实。此稿直接对照数学定义与现有architecture，无需暗示尝试过任何未报告模型。

**待核验／边界**：不作eventtransformer与grid谁更优的普遍结论。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-25"></a>

## R1-25 明确 hybrid loss 的相对权重与证据边界

**操作**：保留 §4.5.3 原引言、公式和变量定义，只替换最后的解释。下列完整A/B/C均包含保留下来的公式上下文，实施时只执行所选整块一次。

**独立审查处理**：接受。保留preliminary evidence，删去普遍最优性句，改成直接相关的equal coefficient与loss/gradient magnitude区别。完整保留公式、denominator及变量定义。

**对应finding**：F03。

**实际原文与定位**

`Chapter_4/chap4.tex` line 133

```latex
All models are trained with the hybrid loss adopted in prior score-informed work~\cite{kim2024method}. It combines frame-wise binary cross-entropy with onset-wise $\ell_1$ loss:
\begin{equation}
\mathcal{L}
= \frac{1}{|\mathcal{J}|}\sum_{(t,p)\in\mathcal{J}} \ell_{\mathrm{bce}}\big(V_{t,p},\hat{V}_{t,p}\big)
+ \frac{1}{|\mathcal{I}|}\sum_{(t,p)\in\mathcal{I}} \left|V_{t,p}-\hat{V}_{t,p}\right|.
\label{eq:scoreinf:loss}
\end{equation}
Here $\mathbf{V}$ is the ground-truth velocity target and $\hat{\mathbf{V}}$ is the predicted velocity output of either the baseline AMT branch or the score-informed system. This hybrid supervision is useful because it constrains both the local onset value and the broader note sustain region, while still keeping note-level precision central to the objective.
```

### A

All models are trained with the hybrid loss adopted in prior score-informed work~\cite{kim2024method}. It combines frame-wise binary cross-entropy with onset-wise $\ell_1$ loss:
\begin{equation}
\mathcal{L}
= \frac{1}{|\mathcal{J}|}\sum_{(t,p)\in\mathcal{J}} \ell_{\mathrm{bce}}\big(V_{t,p},\hat{V}_{t,p}\big)
+ \frac{1}{|\mathcal{I}|}\sum_{(t,p)\in\mathcal{I}} \left|V_{t,p}-\hat{V}_{t,p}\right|.
\label{eq:scoreinf:loss}
\end{equation}
Here $\mathbf{V}$ is the ground-truth velocity target and $\hat{\mathbf{V}}$ is the predicted velocity output of either the baseline AMT branch or the score-informed system. Each component is averaged over its own mask, and the two means have equal relative coefficients. Equal coefficients do not imply equal numerical loss or gradient magnitudes.

### B

All models are trained with the hybrid loss adopted in prior score-informed work~\cite{kim2024method}. It combines frame-wise binary cross-entropy with onset-wise $\ell_1$ loss:
\begin{equation}
\mathcal{L}
= \frac{1}{|\mathcal{J}|}\sum_{(t,p)\in\mathcal{J}} \ell_{\mathrm{bce}}\big(V_{t,p},\hat{V}_{t,p}\big)
+ \frac{1}{|\mathcal{I}|}\sum_{(t,p)\in\mathcal{I}} \left|V_{t,p}-\hat{V}_{t,p}\right|.
\label{eq:scoreinf:loss}
\end{equation}
Here $\mathbf{V}$ is the ground-truth velocity target and $\hat{\mathbf{V}}$ is the predicted velocity output of either the baseline AMT branch or the score-informed system. The frame-wise BCE and onset-wise L1 terms are averaged over their respective active positions and combined with equal relative coefficients. We retain the hybrid objective of Kim et al. (2024), supported by the preliminary comparison with frame-only and onset-only supervision reported in our associated SMC paper. Equal coefficients do not imply equal numerical loss or gradient magnitudes.

### C

All models are trained with the hybrid loss adopted in prior score-informed work~\cite{kim2024method}. It combines frame-wise binary cross-entropy with onset-wise $\ell_1$ loss:
\begin{equation}
\mathcal{L}
= \frac{1}{|\mathcal{J}|}\sum_{(t,p)\in\mathcal{J}} \ell_{\mathrm{bce}}\big(V_{t,p},\hat{V}_{t,p}\big)
+ \frac{1}{|\mathcal{I}|}\sum_{(t,p)\in\mathcal{I}} \left|V_{t,p}-\hat{V}_{t,p}\right|.
\label{eq:scoreinf:loss}
\end{equation}
Here $\mathbf{V}$ is the ground-truth velocity target and $\hat{\mathbf{V}}$ is the predicted velocity output of either the baseline AMT branch or the score-informed system. The two terms supervise complementary parts of the note representation: frame-wise BCE covers the active note region, while onset-wise L1 directly penalises the velocity read during post-processing. Each term is averaged over its own active positions, and the two means receive equal relative coefficients. This retains the hybrid formulation used in the prior work and our preliminary verification.

**评价与推荐**：A直接回答normalisation与实际相对系数；B保留作者及SMC提供稿明确记载的preliminary comparison；C多解释两个目标的角色。推荐B，保留有证据的验证，又不加入every-backbone/dataset最优性免责声明。现有材料中的hybrid-versus-single-target比较不能代替weight-sweep证据；未找到sweep记录也不等于证明作者从未做过。

**待核验／边界**：V-04：实际run的theta、损失整体尺度与作者验证范围仍需对应。固定源码theta=.5和正文sum的相对1:1相同，不能据default证明全部run。正文不另加通用最优性否定句；不得把SMC比较说成已证明最佳相对比例。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-26"></a>

## R1-26 Table4.1 每个 setup 用现有变量逐一解释

**操作**：在 Table4.1 前补一段定义，表格数字保持原样。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_4/chap4.tex` line 182

```latex
We first attach the proposed modules to HPT and denote the resulting systems as Score-HPT. HPT is used as the initial testbed because it is lightweight and prevalent in recent piano transcription work. This lets us isolate the effect of score-informed correction before extending the method to other backbones. Table~\ref{tab:scoreinf_maestro} summarises the results on the MAESTRO test set.
```

`Chapter_4/chap4.tex` line 67

```latex
Consistent with the standard paradigm of score-informed MIDI velocity estimation \cite{kim2024method}, we rasterise the aligned score into pianoroll-like binary matrices at the same time resolution as the AMT output. Let $T$ be the number of frames and $P$ the number of piano keys. In our setting, $T=1001$ and $P=88$. We define the onset matrix $\mathbf{O}\in\{0,1\}^{T\times P}$, the frame matrix $\mathbf{F}\in\{0,1\}^{T\times P}$, and the onset-excluded sustain matrix $\mathbf{F}^{\mathrm{ex}}\in\{0,1\}^{T\times P}$ as
\begin{equation}
\mathbf{F}^{\mathrm{ex}} = \mathbf{F} - \mathbf{O}.
\label{eq:scoreinf:fex}
\end{equation}
We further define the nonzero index sets
\begin{equation}
\mathcal{I} = \{(t,p)\mid O_{t,p}=1\},
\qquad
\mathcal{J} = \{(t,p)\mid F_{t,p}=1\}.
\label{eq:scoreinf:index}
\end{equation}
The onset set $\mathcal{I}$ is used for tokenisation in the Transformer correction module. The frame set $\mathcal{J}$ is used for loss masking.
```

### A

In Table 4.1, audio denotes the standalone HPT velocity branch. The score-informed rows add either the frame-wise BiLSTM or the onset-token Transformer correction module. The onset condition uses the score onset matrix O; onset + frame additionally supplies the active-note matrix F; and onset + frame_ex uses F − O to distinguish sustain from the onset frame. These conditions vary the correction module and its score features under the same MAESTRO training and evaluation setting. Parameter counts refer to the complete velocity-estimation system shown in each row.

**评价与推荐**：对照表中每行和已有 O/F/Fex 定义，避免再创造setup编号。若公式采用label引用，最终改成Table~ref避免编号漂移。

**待核验／边界**：实际train_mode、SMD development subset是否用于设计选择另记V-04；本段不替协议打包票。 方法段当前BiLSTM只展示3P拼接，未展示onset-only维度；需按已有run配置补准确形状，不能推测。 独立复查通过的是O/F/Fex条件文字；onset-only形状和parameter-count范围未被该文字核验。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-27"></a>

## R1-27 完整 AMT 集成作为未来方向，不虚报已验证性能

**操作**：第5章 §5.3 使用A或B作局部score-facing integration说明；第7章跨章future优先用C，和R1-37合并只保留一处。两种接口不强用同一个beat坐标。

**独立审查处理**：接受。修B作用范围；将第5章最小说明和第7章跨章future分开，避免把逐音velocity也强行放beat grid。

**对应finding**：F06。

**实际原文与定位**

`Chapter_5/chap5.tex` line 36

```latex
Given a piano performance audio signal, the system predicts four synchronised output sequences on a frame grid: dynamic levels, dynamic change points, beats, and downbeats. The dynamic targets are the score-facing outputs, while beats and downbeats provide the metrical structure required to align these labels to a symbolic score. This joint design serves two practical modes of use. In the first mode, a reliable beat grid is already available from an aligned score or a score-level AMT system, and the predicted dynamic labels are attached to that grid. In the second mode, no score is available, and the model first predicts beats and downbeats by itself, then uses the estimated grid to place the dynamic labels.
```

`Chapter_7/Conclusion.tex` line 157

```latex
The broader direction is an AMT paradigm in which note detection is only the first layer. A musically useful transcription should not stop at pitch and onset. It should also recover the expressive information that makes the transcription interpretable as performance and usable as symbolic music data. Dynamics is the layer studied in this thesis, but the same logic can extend to articulation, pedal, phrasing, and timbre.
```

### A

These outputs could be attached to the note content of a score-level AMT system to produce dynamics-annotated notation. The present experiments evaluate dynamics and metrical estimation separately from note transcription, so they do not establish the performance of a complete integrated AMT system or an improvement in note-detection accuracy.

### B

For score-facing dynamics, integration would attach the estimated markings to note content on a common metrical grid. This provides a route to expressive notation, while leaving the interaction with note-transcription errors to a complete-system evaluation. The present experiments evaluate the dynamics component under its stated inputs and do not establish a gain in pitch, onset, or offset accuracy.

### C

The models supply complementary expressive layers that could enrich an AMT output. Chapter 4 refines velocity at aligned note onsets, while Chapter 5 supplies score-facing markings on a metrical grid. Combining these layers with note transcription is a natural next step. A complete system would need to evaluate both note-event accuracy and the recovered expressive layer.

**评价与推荐**：第5章推荐A，最小且不重复现有两种用法。B已把metrical grid限定为score-facing markings；C适合第7章，明确velocity用note onsets、markings用metrical grid。两处不复制同一长段。

**合并关系**：R1-23; R1-37。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-28"></a>

## R1-28 state 与 boundary 是互补监督，并非二选一

**操作**：保留 §5.3 现有四个target与beat解码定义，在该段末补所选理由。下列A/B/C为完整拼接段，前面的problem-setting段和后面的thesis-positioning段均保留。

**独立审查处理**：接受逻辑修正。三稿均接在准确原target段后，C明确另一表述可导出边界，B不再重复邻文。

**对应finding**：F07。

**实际原文与定位**

`Chapter_5/chap5.tex` line 38

```latex
More specifically, the dynamic-level target is formulated as a six-class frame-wise prediction problem, including one \textit{blank} class before the first annotated marking and the five score-dynamics classes used in MazurkaBL: \textit{pp}, \textit{p}, \textit{mf}, \textit{f}, and \textit{ff}. The change-point target is binary and indicates whether a contextual transition between adjacent dynamic regimes occurs at a given time. Beats and downbeats are also binary frame-wise targets. At inference time, the frame-wise outputs are converted into beat-synchronous score annotations by sampling the dynamic class at beat locations and snapping detected change points to the nearest beat.
```

`Chapter_5/chap5.tex` line 97

```latex
Change points are determined in two stages. First, we identify all frames whose change-point probability exceeds 75\%. Second, we snap each candidate to the nearest detected beat. This beat-snapping step is motivated by the annotation style of MazurkaBL, where dynamic markings are beat-aligned rather than freely placed in continuous time \cite{kosta2018mazurkabl}. The step also keeps evaluation consistent with prior work \cite{kosta2017thesis}.
```

### A

More specifically, the dynamic-level target is formulated as a six-class frame-wise prediction problem, including one \textit{blank} class before the first annotated marking and the five score-dynamics classes used in MazurkaBL: \textit{pp}, \textit{p}, \textit{mf}, \textit{f}, and \textit{ff}. The change-point target is binary and indicates whether a contextual transition between adjacent dynamic regimes occurs at a given time. Beats and downbeats are also binary frame-wise targets. At inference time, the frame-wise outputs are converted into beat-synchronous score annotations by sampling the dynamic class at beat locations and snapping detected change points to the nearest beat. The dynamic-level head estimates the prevailing state, while the change-point head gives transitions a separate supervision target. Both contribute to the beat-synchronous output.

### B

More specifically, the dynamic-level target is formulated as a six-class frame-wise prediction problem, including one \textit{blank} class before the first annotated marking and the five score-dynamics classes used in MazurkaBL: \textit{pp}, \textit{p}, \textit{mf}, \textit{f}, and \textit{ff}. The change-point target is binary and indicates whether a contextual transition between adjacent dynamic regimes occurs at a given time. Beats and downbeats are also binary frame-wise targets. At inference time, the frame-wise outputs are converted into beat-synchronous score annotations by sampling the dynamic class at beat locations and snapping detected change points to the nearest beat. The separate change-point head gives transitions an explicit supervision target, instead of deriving boundaries only from changes in the predicted level sequence. It complements the beat-wise level output by modelling when a new dynamic region begins.

### C

More specifically, the dynamic-level target is formulated as a six-class frame-wise prediction problem, including one \textit{blank} class before the first annotated marking and the five score-dynamics classes used in MazurkaBL: \textit{pp}, \textit{p}, \textit{mf}, \textit{f}, and \textit{ff}. The change-point target is binary and indicates whether a contextual transition between adjacent dynamic regimes occurs at a given time. Beats and downbeats are also binary frame-wise targets. At inference time, the frame-wise outputs are converted into beat-synchronous score annotations by sampling the dynamic class at beat locations and snapping detected change points to the nearest beat. Boundaries can also be derived from changes between adjacent beat-wise level predictions. We instead give transitions their own supervision through a separate change-point head, alongside the level prediction. This lets the model learn the boundary target directly.

**随后保留的上下文**

This task directly matches the role assigned to Chapter~5 in the thesis plan: score-level dynamics should be represented as a beat-synchronous interface comprising dynamic levels, change points, and metrical structure. It also supports the broader thesis objective of recovering expressive labels without changing the underlying note content or timing.

**评价与推荐**：推荐B：不重复定义frame grid和beat mask，只补显式boundary supervision这一独特理由。A最短；C明确承认可由相邻level变化导出边界，再说明本工作选择。删除“beat-wise levels本身不能区分stable/new region”的错误必需性论证，也不借未做的独立CPt消融宣称因果增益。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-29"></a>

## R1-29 共享表征、分头 loss 与 decoding 连接同时说明

**操作**：在 §5.5.2 metrical post-processing 后补说明；Fig5.2提案副本用虚线连接两个输出至共同postprocessing框，而非新增learnedheadedge。

**独立审查处理**：接受精确归因。三稿正文保留；外部证据区分normal/default已核实实现与最终run映射。

**对应finding**：F08。

**实际原文与定位**

`Chapter_5/chap5.tex` line 79

```latex
The shared encoder provides a common latent representation, but the tasks remain acoustically diverse. To reduce negative transfer, we use a Multi-gate Mixture-of-Experts (MMoE) layer \cite{ma2018mmoe} as a task-aware decoder.
```

`Chapter_5/chap5.tex` line 95

```latex
The model outputs frame-wise probabilities, which are converted into discrete musical events through tailored post-processing. For beat and downbeat detection, we use the thresholding and local-maximum peak-picking steps of \cite{foscarin2024beat}: probabilities are thresholded at 50\%, and peak picking is applied within a 7-frame local neighbourhood (radius 3 at 50~fps). For dynamic markings, the dynamic level at each beat is determined by taking the \texttt{argmax} of the class probabilities at that frame. When an external beat grid is available, this sampling step is performed on that grid; otherwise, the model's own beat predictions are used, which gives the fully end-to-end mode considered in this chapter.
```

### A

Beat and downbeat predictions share the encoder and expert pool, but use separate heads and loss terms. Their event outputs are linked during post-processing: when predicted beats are available, detected downbeats are snapped to the nearest predicted beat and duplicate positions are removed. No explicit beat–downbeat consistency term is added to the training loss.

### B

The beat and downbeat tasks are coupled through shared representation learning and through decoding, rather than by a direct connection between their output heads. Each head has its own shift-tolerant loss. In post-processing, downbeats are moved to the nearest predicted beat when a beat sequence is available, with duplicate events removed. This enforces the event-level relation at decoding time without adding a learned cross-head constraint.

### C

The architecture separates task-specific prediction from musical consistency at the output. The shared encoder and MMoE experts let beat and downbeat learning use common evidence, while separate gates, heads, and losses preserve their task-specific decisions. The decoder then snaps downbeats to predicted beats where available. A stronger consistency objective during training is a possible extension, but is not part of the reported model.

**评价与推荐**：固定beat_postproc.py明确有条件snap和dedup，符合作者第二条回复。B清楚区分coupling阶段；A最短，C更完整但会与MMoE段重复。不再写“只有共享，完全无连接”。

**待核验／边界**：实现归因已增强核验：保留代码的normal/default evaluation路径在final_evaluation.py的evaluate(advanced_only=False)创建minimal Postprocessor，并在normal downbeat分支调用beat/downbeat logits；beat_postproc.py在有beat时snap和deduplicate。--advanced会走不同分支。作者说明与此实现相互支持；最终表格/各baseline/实际run对应仍留外部记录核验，不在候选正文反复怀疑作者。图只连接outputs至post-processing，不新增learned head edge。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-30"></a>

## R1-30 cross-dataset 是测迁移边界，不是分离风格因果

**操作**：将 §5.7.3 原首段整体替换为A/B/C；将该小节原selection段整体替换为下方共用protocol；§5.6.1重复selection段缩成指向此处的两句。保留表值及表后实测比较，不把disclosure当作表源已核实。

**独立审查处理**：接受。重写完整目的段，明确target labels参与selection；以替换现有selection段与缩短前文重复的方式拼接，不再插第三套流程。

**对应finding**：F09。

**实际原文与定位**

`Chapter_5/chap5.tex` line 328

```latex
The 5-fold MazurkaBL evaluation already gives a partial test of generalisation, because the folds are piece-disjoint and the model is always evaluated on unseen mazurkas within the same corpus. However, it remains an in-domain setting: performer pool, recording conditions, repertoire family, and annotation conventions are all inherited from MazurkaBL. We therefore add a stricter cross-dataset experiment on Vienna4x22 and Batik-plays-Mozart, using them as test-only corpora after the MazurkaBL training stage.
```

`Chapter_5/chap5.tex` line 392

```latex
The cross-dataset results make this distinction more concrete. If score dynamics were merely a continuous loudness variable relabelled into five fixed bins, an out-of-domain corpus with compatible audio quality would mainly cause smooth calibration errors. Instead, Vienna4x22 shows that the symbolic prior itself matters: a passage that is moderate in acoustic intensity may be notated as \textit{p}, \textit{mf}, or \textit{f} depending on the local phrase, edition, and corpus convention. A model trained on MazurkaBL carries a learned expectation about how often each of these labels should occur, and this expectation can become wrong even when the metrical grid remains reasonably stable. The model is therefore learning an acoustic, metrical, and editorial mapping at the same time.
```

`Chapter_5/chap5.tex` line 330

```latex
For each method and input feature, the five checkpoints obtained from MazurkaBL cross-validation are evaluated on each external corpus without fine-tuning. For multitask systems, the transferred fold is selected by the five-class dynamic F1 score because the dynamic label is the primary output of this chapter; the change-point, beat, and downbeat scores are then reported from the same fold. For single-task systems, each task is trained independently, so the best transferred fold is selected separately for the corresponding task. This mirrors the structure of the in-domain experiments, where the single-task baselines are independent models while the multitask system is a single shared model.
```

`Chapter_5/chap5.tex` line 187

```latex
Beyond the in-domain MazurkaBL evaluation, Section~\ref{ssec:audiodyn_cross_dataset} reports a test-only cross-dataset evaluation. For each architecture and front-end variant, the five MazurkaBL fold models are all evaluated on Vienna4x22 and Batik-plays-Mozart without fine-tuning. For the multitask variants, the external table selects the fold with the best dynamic F1 on the target corpus and reports the other task scores from the same checkpoint. For the single-task variants, each task has its own fold models, so the best fold is selected separately for the corresponding task. This protocol is intended as a reproducible transfer diagnostic: it asks whether a MazurkaBL-trained fold checkpoint can be reused on an external classical-piano corpus, while the main MazurkaBL table remains the within-corpus benchmark reported as mean and standard deviation over all folds. The per-fold outputs are retained so that the selected fold can be traced.
```

### A

The 5-fold MazurkaBL evaluation already gives a partial test of generalisation because the folds are piece-disjoint. It remains an in-domain setting, with the performer pool, recording conditions, repertoire family, and annotation conventions inherited from MazurkaBL. We therefore evaluate transfer to Vienna4x22 and Batik-plays-Mozart after training on MazurkaBL. These external tests change several corpus conditions together and do not isolate a composer or performer effect.

### B

Piece-disjoint cross-validation tests generalisation to unseen mazurkas within MazurkaBL. Cross-dataset evaluation additionally tests the learned mapping under changes in repertoire, performers, recording conditions, and annotation conventions. These factors vary together in Vienna4x22 and Batik-plays-Mozart, so the experiment diagnoses combined corpus transfer rather than isolating a composer or performer effect.

### C

The external tests extend the piece-disjoint MazurkaBL evaluation by asking how the learned mapping transfers under different corpus conditions. Vienna4x22 and Batik-plays-Mozart change repertoire, performers, recording conditions, and score-label conventions together. Their results therefore describe transfer to those corpora, while a separate balanced design would be needed to isolate the individual factors.

**与所选路线共同执行的准确替换**（protocol仍以真实run规则确认作条件）

`Chapter_5/chap5.tex` line 330

原：

For each method and input feature, the five checkpoints obtained from MazurkaBL cross-validation are evaluated on each external corpus without fine-tuning. For multitask systems, the transferred fold is selected by the five-class dynamic F1 score because the dynamic label is the primary output of this chapter; the change-point, beat, and downbeat scores are then reported from the same fold. For single-task systems, each task is trained independently, so the best transferred fold is selected separately for the corresponding task. This mirrors the structure of the in-domain experiments, where the single-task baselines are independent models while the multitask system is a single shared model.

完整replacement：

For each method and input feature, the five checkpoints obtained from MazurkaBL cross-validation are evaluated on each external corpus without fine-tuning. Under the reporting rule stated here, the multitask fold is selected by dynamic F1 on the target corpus, and the other task scores are reported from that same checkpoint. For single-task systems, the transferred fold is selected separately for each task. Selection therefore uses target-corpus labels, even though no fine-tuning is performed. The external scores are a target-selected transfer diagnostic and may be optimistic relative to evaluation with model selection fixed before target labels are inspected. The within-corpus MazurkaBL benchmark remains a mean and standard deviation over all folds.

`Chapter_5/chap5.tex` line 187

原：

Beyond the in-domain MazurkaBL evaluation, Section~\ref{ssec:audiodyn_cross_dataset} reports a test-only cross-dataset evaluation. For each architecture and front-end variant, the five MazurkaBL fold models are all evaluated on Vienna4x22 and Batik-plays-Mozart without fine-tuning. For the multitask variants, the external table selects the fold with the best dynamic F1 on the target corpus and reports the other task scores from the same checkpoint. For the single-task variants, each task has its own fold models, so the best fold is selected separately for the corresponding task. This protocol is intended as a reproducible transfer diagnostic: it asks whether a MazurkaBL-trained fold checkpoint can be reused on an external classical-piano corpus, while the main MazurkaBL table remains the within-corpus benchmark reported as mean and standard deviation over all folds. The per-fold outputs are retained so that the selected fold can be traced.

完整replacement：

We additionally evaluate the MazurkaBL-trained fold models on Vienna4x22 and Batik-plays-Mozart without fine-tuning. The target-informed fold-selection and reporting rules are specified in Section~\ref{ssec:audiodyn_cross_dataset}.

**评价与推荐**：A最接近原段并保留piece-disjoint与in-domain区别；B更清楚压缩combined shift，去掉了向评审反驳的opening；C改为how transfer，不把mixed outcomes定义成stops transferring。推荐B。selection disclosure是独立且必要的具体协议说明，不能用一般distribution-shift限制代替；其两处重复合并到一处。

**待核验／边界**：V-05仍开放。共用protocol仅在当前书面selection规则确实对应最终表来源时采用；保存输出与per-task maxima/共同dynamic-best规则存在待对齐差异，macro-vs-weighted也未解决。不填新结果、不由aggregated scores反推macro-F1、不要求重训。表源核实后按真实规则定稿，不能只靠加disclosure就标成已解决。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-31"></a>

## R1-31 不用未测的 simpler 或 efficiency 优越性

**操作**：替换 §6.2 对 synthetic-data transfer 的过渡段；作者想强调省标签／更直接，不能扩大成已测运行效率。

**独立审查处理**：三稿第一轮通过；保留A/B，删减C末尾通用比较否定句，直接说明监督可用性与接口要求。

**实际原文与定位**

`Chapter_6/chap6.tex` line 31

```latex
This chapter takes a different and simpler route. Instead of training on synthesised audio with synthetic labels, the front-end estimator is trained directly against real performance audio. The synthesiser is involved at training time only as a differentiable interface that connects predicted velocities to a measurable property of the real recording. This avoids the synthesis-to-performance domain gap that dominates synthetic-data transfer pipelines, at the cost of needing a differentiable supervision interface that is reliable across the instruments of interest.
```

### A

This chapter instead adapts the estimator directly on real performance audio without requiring target-domain velocity labels. A differentiable renderer supplies the indirect training signal, while renderer mismatch remains a limitation.

### B

This chapter takes a more direct route to target-domain adaptation. Rather than relying only on transfer from synthetically labelled audio, the estimator is adapted using real performance recordings and a differentiable rendering interface. This reduces dependence on target velocity annotation, but does not remove the need to model or approximate the renderer.

### C

The practical aim is to reduce dependence on unavailable target-domain velocity labels. We therefore train the adaptation stage against real performance audio through a differentiable interface. The advantage concerns access to supervision, while the renderer or proxy still has to be built and matched to the target setting.

**评价与推荐**：B保留作者更直接／减少annotation需求的意思，也与提供的ISMIR稿more direct route一致。A最短；C把对比落在supervision availability与接口要求，解释较长，B更紧凑。作者的more efficient可理解为减少target annotation需求，未经测量不直接写一般效率优势。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-32"></a>

## R1-32 V^(0) 是粗估 roll，Vhat 是 correction 后的逐音值

**操作**：将 §6.4.1 两个原段替换为下列两段完整拼接稿：只澄清fixed架构和V^(0)/Vhat含义，保留原全部前端采样率、fps、FFT、hop、Hann、checkpoint来源和Chapter4架构引用。

**独立审查处理**：接受并修复。给出两段完整候选，数值配置与后文FFT回指均保留，未改研究设置。

**对应finding**：F16。

**实际原文与定位**

`Chapter_6/chap6.tex` line 91

```latex
VeloEst acts as the shared front-end of the framework, estimating note-wise MIDI velocities $\hat{V}$ from the performance audio and aligned note events. We use the score-informed HPT model with onset and frame as score-guidance, which is identified as the best VeloEst configuration in Chapter~\ref{ch:scoreinf}~\cite{he2026score}. We keep its architecture unchanged and use the publicly available checkpoint trained on MAESTRO with ground-truth velocity supervision $\mathcal{L}_{\mathrm{velo}}$. This fixed estimator keeps the cross-instrument experiment focused on the supervision interface rather than on introducing a new velocity-estimation architecture.
```

`Chapter_6/chap6.tex` line 93

```latex
The estimator has two stages. The acoustic module, borrowed from the High-Resolution Piano Transcription system~\cite{kong2021hpt}, takes log-Mel spectrograms computed at $100$\,fps from $22050$\,Hz mono audio (FFT size $2048$, hop $221$\,samples, Hann window) as input and predicts a coarse velocity roll $V^{(0)}$. A score-informed Transformer then refines $V^{(0)}$ into $\hat{V}$ using aligned note information. The detailed architecture and supervised training procedure are given in Chapter~\ref{ch:scoreinf}; the present chapter treats this estimator as a fixed black-box front-end whose checkpoint is then adapted.
```

### A

VeloEst acts as the shared front-end of the framework, estimating note-wise MIDI velocities $\hat{V}$ from the performance audio and aligned note events. We use the score-informed HPT model with onset and frame as score-guidance, which is identified as the best VeloEst configuration in Chapter~\ref{ch:scoreinf}~\cite{he2026score}. We keep its architecture unchanged and use the publicly available checkpoint trained on MAESTRO with ground-truth velocity supervision $\mathcal{L}_{\mathrm{velo}}$. Using this estimator keeps the cross-instrument experiment focused on the supervision interface rather than on introducing a new velocity-estimation architecture.

The estimator has two stages. The acoustic module, borrowed from the High-Resolution Piano Transcription system~\cite{kong2021hpt}, takes log-Mel spectrograms computed at $100$\,fps from $22050$\,Hz mono audio (FFT size $2048$, hop $221$\,samples, Hann window) as input and predicts a coarse velocity roll $V^{(0)}$. A score-informed Transformer then refines $V^{(0)}$ into $\hat{V}$ using aligned note information. Here, $V^{(0)}$ denotes the intermediate acoustic estimate, while $\hat{V}$ denotes the corrected onset values passed to the rendering interface; the superscript does not identify a pre-adaptation checkpoint. The detailed architecture and supervised training procedure are given in Chapter~\ref{ch:scoreinf}. The architecture is retained during adaptation, while VeloEst parameters are updated and the synthesis or proxy back-end remains frozen.

**随后保留的上下文**

\subsection{Adaptation via Diff-Synth}
\label{ssec:bp:adapt_diffsynth}

**评价与推荐**：接受审查。round1只给解释段会删被PHE/OSF节再引用的FFT设置；本稿完整保留配置。没有把100fps/hop221重新调参或悄改为另一值。V^(0)表示中间声学阶段而非adaptation前checkpoint；结构不变和参数更新分别说明。

**待核验／边界**：仅Ch.4实际训练模式继续由V-04对应；此处Ch.6自身已明确adaptation更新VeloEst、后端冻结。本稿是源文提案，不宣称已应用或重新编译。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-33"></a>

## R1-33 DDSP fidelity 是限制，退化不等于因果证明

**操作**：在 §6.4.2 末增加，并把 Results 中确定性因果说法改为 consistent with。

**独立审查处理**：接受。修C隐含因果，并展示原已提出的三处跨段替换的完整拼接文本；测量结果保持。

**对应finding**：F11。

**实际原文与定位**

`Chapter_6/chap6.tex` line 111

```latex
The advantage of this interface is that it exposes the front end to rich waveform gradients. The risk, already noted in Section~\ref{sec:bp:related}, is that any timbral or recording mismatch between $\tilde{a}$ and $a$ also enters the gradient. When the synthesiser is not a faithful match for the target recordings, the gradient can become dominated by nuisance compensation rather than by velocity correction.
```

`Chapter_6/chap6.tex` line 429

```latex
Second, on guitar (Table~\ref{tab:bp_results_guitar}) Diff-SFProxy achieves the best $r_{\mathrm{BSSL}}$ and $r_{\mathrm{BSTL}}$ on both GAPS and FL datasets, outperforming flat velocity, zero-shot transfer, and Diff-Synth across all back-end crop lengths. Diff-Synth, by contrast, does not reliably improve guitar performance and can degrade it. On FL dataset, the $5$\,s Diff-Synth back-end falls below flat velocity in $r_{\mathrm{BSSL}}$ ($0.646$ vs.\ $0.714$). This supports the concern raised in Section~\ref{ssec:bp:adapt_diffsynth}: waveform-level objectives are more exposed to timbral and room-acoustic mismatch than parameter-level supervision.
```

### A

DDSP-Piano and DDSP-Guitar-Synth are differentiable approximations of the target instruments. Their timbre and velocity response need not match the real recordings. The observed degradation after Diff-Synth adaptation is consistent with acoustic mismatch, but we have not separately measured reconstruction fidelity or the accuracy of velocity-related gradients on the target data.

### B

The waveform back-ends are used as differentiable approximations rather than exact reproductions of the recorded instruments. Their usefulness depends both on acoustic fidelity and on whether changing velocity produces the appropriate change in sound. The Diff-Synth results are consistent with a mismatch in this interface, but do not isolate its cause: reconstruction fidelity and velocity-gradient accuracy were not measured separately on the target recordings.

### C

A differentiable synthesiser can offer useful gradients without reproducing every detail of a recording, but the relevant error is not timbral fidelity alone. Its velocity-to-sound response must also be suitable for the adaptation target. The present comparison shows weaker adaptation with the selected Diff-Synth back-ends, but does not isolate the cause of that degradation. The conclusion is limited to the tested interfaces and recordings.

**评价与推荐**：推荐B，局部A/B/C均已通过第二轮复审，保持原文。共同同步涉及三个完整段落、五个逐句操作：保留FL的0.083/0.01及crop-length观察，删除无独立依据的普遍稳定性末句，并把unobserved-controls吸收写成may therefore absorb。没有改结果、设置或模型设计。

**逐句同步提案**

- `Chapter_6/chap6.tex` line 36
  - 原：A waveform or spectral loss therefore spends much of its gradient budget on residual mismatch rather than on velocity-dependent behaviour.
  - 拟：A waveform or spectral loss can be influenced by residual mismatch as well as velocity-dependent behaviour.

- `Chapter_6/chap6.tex` line 431
  - 原：Longer crops give waveform-level objectives more of the underlying timbral mismatch to fit, while parameter-level supervision sees only per-note targets and is therefore much less sensitive to crop length.
  - 拟：The crop-length pattern is consistent with greater exposure of the waveform objective to acoustic mismatch, but the present comparison does not isolate that mechanism.

- `Chapter_6/chap6.tex` line 457
  - 原：Diff-SFProxy avoids this contamination by treating velocity as the only loudness-shaping degree of freedom, but the choice carries its own cost.
  - 拟：Diff-SFProxy restricts the adapted control to velocity, but this does not remove effects of unobserved controls from the target audio.

**第三轮补充的两个准确操作**

- `Chapter_6/chap6.tex` line 431
  - 删除原整句：This mirrors a long-standing observation in inverse-problem design: a supervision signal that only depends on the latent variable of interest is more stable than a high-dimensional signal that mixes that variable with many nuisance factors.
  - 保留0.083、0.01、2s/5s观察与consistent-with解释。

- `Chapter_6/chap6.tex` line 457
  - 原：The recovered velocity absorbs effects that, in the real performance, came from other parallel controls.
  - 拟：The recovered velocity may therefore absorb effects that, in the real performance, came from other parallel controls.

**上述同步替换的完整段落效果**

`Chapter_6/chap6.tex` line 36

Two limitations of waveform-level supervision are relevant here. First, a Diff-Synth only approximates the real instrument; its waveform statistics differ from real recordings in timbre, articulation, microphone response, and room acoustics. A waveform or spectral loss can be influenced by residual mismatch as well as velocity-dependent behaviour. Second, an instrument-specific Diff-Synth requires a dedicated design: piano-oriented synthesisers expect piano-specific controls such as pedal state, while guitar-oriented synthesisers expect string-wise trajectories. Reusing one Diff-Synth across instruments is therefore impractical.

`Chapter_6/chap6.tex` line 431

Third, the asymmetry between the two adaptation interfaces widens with crop length. On FL dataset, Diff-Synth's $r_{\mathrm{BSSL}}$ falls by $0.083$ when moving from $2$\,s to $5$\,s, while Diff-SFProxy's $r_{\mathrm{BSSL}}$ varies within $0.01$. The crop-length pattern is consistent with greater exposure of the waveform objective to acoustic mismatch, but the present comparison does not isolate that mechanism.

`Chapter_6/chap6.tex` line 457

Velocity is not the only MIDI control that shapes rendered dynamics: continuous controllers can also encode within-note loudness variation~\cite{ryu2024midfild}. Pedal settings and room response also affect the synthesised piano waveform and are explicitly modelled by DDSP-Piano~\cite{renault2023ddsp_piano}. Consequently, when adaptation updates only velocity, the velocity gradient can become entangled with residuals caused by fixed or unobserved controls. Diff-SFProxy restricts the adapted control to velocity, but this does not remove effects of unobserved controls from the target audio. The recovered velocity may therefore absorb effects that, in the real performance, came from other parallel controls.

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-34"></a>

## R1-34 Huber 的梯度理由与 MAE 对照边界

**操作**：保留公式与其后的β=1.0、valid notes、PHE/OSF 1:1定义，只替换该段最后的损失理由句。下列稿已与保留部分拼接，每稿只出现一次β。

**独立审查处理**：接受。明确did not conduct；只替loss理由句，保留设置和component weighting。

**对应finding**：F12。

**实际原文与定位**

`Chapter_6/chap6.tex` line 116

```latex
In the Diff-SFProxy path, the back-end is a frozen differentiable proxy $P$ of an instrument-specific SoundFont. Let $F$ denote the note-wise loudness-related acoustic parameter extractor that reads audio conditioned on the note events $E$. Both $F$ and $P$ output the same kind of low-dimensional, note-wise dynamics descriptor; their precise construction is deferred to Section~\ref{sec:bp:diffsfproxy}. Given predicted velocities $\hat{V}$, the two feature streams are
\begin{equation}
\label{eq:bp_sfproxy_features}
Z = F(a, E), \qquad \tilde{Z} = P(E, \hat{V}).
\end{equation}
The adaptation loss is a Huber (Smooth-$L_1$) distance between the two extracted parameter groups,
\begin{equation}
\label{eq:bp_param_loss}
\mathcal{L}_{\mathrm{params}} = \mathrm{Huber}_\beta\!\left(\tilde{Z} - Z\right),
\end{equation}
with the default $\beta = 1.0$. Each $Z_n = (\mathrm{PHE}_n, \mathrm{OSF}_n) \in \mathbb{R}^2$ contains the two note-wise parameters defined in Section~\ref{ssec:bp:acoustic_params}, and the loss averages over both components and all valid notes, weighting PHE and OSF equally ($1{:}1$). The Huber form tolerates outliers from onset contamination such as overlapping notes, while the parameter-space objective concentrates gradients on note intensity and attack behaviour rather than on waveform details that are weakly related to velocity.
```

### A

In the Diff-SFProxy path, the back-end is a frozen differentiable proxy $P$ of an instrument-specific SoundFont. Let $F$ denote the note-wise loudness-related acoustic parameter extractor that reads audio conditioned on the note events $E$. Both $F$ and $P$ output the same kind of low-dimensional, note-wise dynamics descriptor; their precise construction is deferred to Section~\ref{sec:bp:diffsfproxy}. Given predicted velocities $\hat{V}$, the two feature streams are
\begin{equation}
\label{eq:bp_sfproxy_features}
Z = F(a, E), \qquad \tilde{Z} = P(E, \hat{V}).
\end{equation}
The adaptation loss is a Huber (Smooth-$L_1$) distance between the two extracted parameter groups,
\begin{equation}
\label{eq:bp_param_loss}
\mathcal{L}_{\mathrm{params}} = \mathrm{Huber}_\beta\!\left(\tilde{Z} - Z\right),
\end{equation}
with the default $\beta = 1.0$. Each $Z_n = (\mathrm{PHE}_n, \mathrm{OSF}_n) \in \mathbb{R}^2$ contains the two note-wise parameters defined in Section~\ref{ssec:bp:acoustic_params}, and the loss averages over both components and all valid notes, weighting PHE and OSF equally ($1{:}1$). Huber is quadratic for small residuals and L1-like for larger residuals, giving smoother gradients near zero while limiting the influence of large errors. We did not conduct a dedicated comparison with MAE.

### B

In the Diff-SFProxy path, the back-end is a frozen differentiable proxy $P$ of an instrument-specific SoundFont. Let $F$ denote the note-wise loudness-related acoustic parameter extractor that reads audio conditioned on the note events $E$. Both $F$ and $P$ output the same kind of low-dimensional, note-wise dynamics descriptor; their precise construction is deferred to Section~\ref{sec:bp:diffsfproxy}. Given predicted velocities $\hat{V}$, the two feature streams are
\begin{equation}
\label{eq:bp_sfproxy_features}
Z = F(a, E), \qquad \tilde{Z} = P(E, \hat{V}).
\end{equation}
The adaptation loss is a Huber (Smooth-$L_1$) distance between the two extracted parameter groups,
\begin{equation}
\label{eq:bp_param_loss}
\mathcal{L}_{\mathrm{params}} = \mathrm{Huber}_\beta\!\left(\tilde{Z} - Z\right),
\end{equation}
with the default $\beta = 1.0$. Each $Z_n = (\mathrm{PHE}_n, \mathrm{OSF}_n) \in \mathbb{R}^2$ contains the two note-wise parameters defined in Section~\ref{ssec:bp:acoustic_params}, and the loss averages over both components and all valid notes, weighting PHE and OSF equally ($1{:}1$). Huber is quadratic near zero and L1-like for larger residuals. We chose it for its smoother small-error gradients than MAE; we did not conduct a dedicated comparison with MAE.

### C

In the Diff-SFProxy path, the back-end is a frozen differentiable proxy $P$ of an instrument-specific SoundFont. Let $F$ denote the note-wise loudness-related acoustic parameter extractor that reads audio conditioned on the note events $E$. Both $F$ and $P$ output the same kind of low-dimensional, note-wise dynamics descriptor; their precise construction is deferred to Section~\ref{sec:bp:diffsfproxy}. Given predicted velocities $\hat{V}$, the two feature streams are
\begin{equation}
\label{eq:bp_sfproxy_features}
Z = F(a, E), \qquad \tilde{Z} = P(E, \hat{V}).
\end{equation}
The adaptation loss is a Huber (Smooth-$L_1$) distance between the two extracted parameter groups,
\begin{equation}
\label{eq:bp_param_loss}
\mathcal{L}_{\mathrm{params}} = \mathrm{Huber}_\beta\!\left(\tilde{Z} - Z\right),
\end{equation}
with the default $\beta = 1.0$. Each $Z_n = (\mathrm{PHE}_n, \mathrm{OSF}_n) \in \mathbb{R}^2$ contains the two note-wise parameters defined in Section~\ref{ssec:bp:acoustic_params}, and the loss averages over both components and all valid notes, weighting PHE and OSF equally ($1{:}1$). The parameter targets can contain residual error from overlapping notes and imperfect onset alignment. Huber combines a smooth small-error region with linear growth for larger residuals. This motivates the chosen objective; a dedicated comparison with MAE was not conducted.

**评价与推荐**：推荐A，技术理由和未做专门MAE比较都明确，且最少改动。B已用did not conduct排除“做过但未证实”的歧义；C保留参数污染动机但略长。三个拼接稿均保留β与1:1，不重复设置，也不声称large-error线性惩罚是Huber独有优势。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-35"></a>

## R1-35 Fig6.2 已提 rendered audio，补图内 teacher 路径

**操作**：原caption已有SoundFont-rendered，不声称整项未回应。候选副本在teacher支路的SoundFont和targetparams之间加框“SoundFont-rendered audio”；当前资产teacher在左侧，不照搬评审right的位置。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_6/chap6.tex` line 201

```latex
\begin{figure}[t]
\centering
\includegraphics[width=0.68\columnwidth]{Chapter_6/figures/p2.jpg}
\caption{An encoder-only Transformer maps padded note sequences to per-note PHE/OSF targets extracted from SoundFont-rendered audio.}
\label{fig:bp_proxy_arch}
\end{figure}
```

### A

Offline training of the differentiable SoundFont proxy. Sampled MIDI notes and velocities are rendered by the SoundFont; PHE and OSF extracted from this rendered audio provide the teacher targets. The Transformer predicts the same parameters from the note sequence. Real performance audio is used later for VeloEst adaptation, not to generate these offline teacher targets.

**评价与推荐**：caption区分两训练阶段；图内明确中间audio节点即可。现图已有“Render MIDI to Audio”，因此也可选择仅保留原图／增加目标标签，不必重新设计整个架构。

**待核验／边界**：【待绘图副本与视觉核验】。任何修改只在提案副本，当前图源不变。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-36"></a>

## R1-36 自动选择 SoundFont 留为明确未来工作

**操作**：在 §6.9.4 第一段后补两至三句，不追加实验。

**独立审查处理**：接受。修C的过重概念论证；选择哪个renderer会影响目标，自动或人工选择本身不必改变定义。

**对应finding**：F13。

**实际原文与定位**

`Chapter_6/chap6.tex` line 517

```latex
Several boundaries should be kept in mind. First, the recovered velocity is renderer-conditioned (Section~\ref{ssec:bp:scope}). The SoundFont is selected by ear from a small candidate pool. A mismatched SoundFont would produce a teacher signal that the target recordings cannot match, so renderer choice is part of the operational definition rather than an incidental detail.
```

### A

Automating SoundFont selection is a natural extension. A matching procedure could compare candidate renderers with representative target recordings, but should assess their velocity response as well as timbral similarity.

### B

Automatic SoundFont selection could make the framework easier to apply to larger or more varied corpora. Such a procedure would need to consider both timbral match and the velocity-dependent response that supplies the training signal. The present study uses by-ear selection and does not evaluate an automated selection method.

### C

Because the selected renderer conditions the recovered velocity, an automated selection procedure should assess its velocity response as well as timbral similarity. Developing and evaluating such a procedure remains future work; the current results retain the stated manually selected SoundFonts.

**评价与推荐**：推荐A，局部两句足够；B保留更完整的当前/未来说明也可。C已把影响操作目标的因素准确归于selected renderer，而非自动化本身。没有新增算法或实验承诺。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-37"></a>

## R1-37 完整 AMT 与 note accuracy 的回应统一放一处

**操作**：采用R1-27C作为第7章唯一跨章integration段；本项不再另插第二段。保留本项原单句供压缩该段时使用。

**独立审查处理**：通过；执行关系明确为R1-27C与本项合并，避免两套未来段落。

**实际原文与定位**

`Chapter_7/Conclusion.tex` line 157

```latex
The broader direction is an AMT paradigm in which note detection is only the first layer. A musically useful transcription should not stop at pitch and onset. It should also recover the expressive information that makes the transcription interpretable as performance and usable as symbolic music data. Dynamics is the layer studied in this thesis, but the same logic can extend to articulation, pedal, phrasing, and timbre.
```

### A

Integrating the proposed dynamics layers with note transcription is a natural next step. Such a system should be evaluated for expressive usefulness as well as pitch, onset, and offset accuracy; the present component-level studies do not establish an improvement in those note-transcription measures.

**评价与推荐**：保留作者对human-prefer与客观指标可能不一致的判断，但不把这种可能性写成本文已测结论。

**合并关系**：R1-27。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r1-38"></a>

## R1-38 明确未显式恢复渐强渐弱，加入 span 输出方向

**操作**：在 Ch.7 §7.3 score-dynamics 限制段后补；若选B/C，后一句放 §7.4.2 或单独简短future段，避免§7.3重复。

**独立审查处理**：接受同表额外判断。C改为not explicitly represented，避免implicit暗示已间接可靠恢复hairpins。B保留。

**对应finding**：F13。

**实际原文与定位**

`Chapter_7/Conclusion.tex` line 115

```latex
Third, score dynamics is inherently contextual. A dynamic marking is not a fixed loudness threshold. It depends on edition, local musical function, register, texture, and phrase context. Chapter~\ref{ch:audiodyn} treats score dynamics as a beat-synchronous symbolic target because that is the most useful interface for notation and analysis. The resulting labels should therefore be read as score-facing annotations under a specific annotation convention, not as universal statements about physical loudness.
```

`Chapter_5/chap5.tex` line 399

```latex
Several limitations should be kept in mind. First, the dynamic vocabulary is restricted to the five static score levels present in MazurkaBL plus a \textit{blank} class. The model does not explicitly represent longer-span symbols such as \textit{crescendo} and \textit{diminuendo}; instead, it captures local transitions through change points. Second, the beat-aligned post-processing reflects the annotation style of MazurkaBL. This is musically sensible for this dataset, but it may not transfer directly to corpora with different editorial conventions.
```

### A

The score-dynamics model is restricted to the five static levels in MazurkaBL and their change points. It does not explicitly recover crescendo, diminuendo, or other span-based expressive symbols, which remain future targets.

### B

The five static levels and change points studied in Chapter 5 do not cover the full dynamics vocabulary. A change point indicates a boundary between regions; it does not specify the onset, duration, or direction of a crescendo or diminuendo. Extending the output to such spans would require compatible annotations and an evaluation of both the symbol and its temporal extent.

### C

Score dynamics includes sustained instructions as well as discrete levels. The present model estimates static levels and local transitions; gradual directions such as crescendo and diminuendo are not explicitly represented. A future score-facing interface could represent these as labelled spans alongside the beat-wise levels, preserving the distinction between a gradual instruction and an abrupt change of dynamic state.

**评价与推荐**：A最短；B更具体说明change points与gradual-span输出的区别，把限制和未来需求连起来；C更偏未来接口叙述，并已明确not explicitly represented。推荐B，不要求本轮增加实验。

**合并关系**：R1-12。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r2-01"></a>

## R2-01 现有章节首尾已经显式回应中心问题，推荐保留

**操作**：推荐不追加四段重复导语；保留现有 Overview/Summary，由 R1-15 修正 Ch.3 条件用语，R1-06 澄清 Ch.6 与S2。

**独立审查处理**：独立审查已逐稿检查；本轮保留通过路线的原文，作者决定和实际执行均未发生。

**实际原文与定位**

`Chapter_3/chap3.tex` line 13

```latex
This chapter addresses Scenario~S1, the most controlled setting in the thesis map. Here the symbolic notes and their timing are already known, but the note-level velocity is missing, flattened, or musically uninformative. The chapter therefore asks a focused question: can useful note-level dynamics be recovered from symbolic structure alone, without changing the original composition?
```

`Chapter_4/chap4.tex` line 8

```latex
This chapter addresses Scenario S2 of the thesis. In this setting, a performance audio recording and an aligned symbolic score are both available. This situation is common in music education, rehearsal analysis, and curated audio--score archives. The score supplies reliable note content and approximate temporal structure. However, its expressive information is often incomplete, simplified, or unreliable. At the same time, modern automatic music transcription (AMT) systems can estimate note-level MIDI velocity from audio, but these estimates remain noisy and sensitive to acoustic domain shift. The central question of this chapter is: \emph{when note events are already known from a score, how should score information be used to improve AMT-estimated velocity without redesigning the whole transcription backbone?}
```

`Chapter_5/chap5.tex` line 11

```latex
Score-level dynamic markings such as \emph{p}, \emph{mf}, and \emph{f} provide the principal human-readable description of musical intensity in notated music. These markings are inherently relative, are naturally indexed by the beat grid rather than by individual note onsets, and cannot in general be inferred from the symbolic score itself. This chapter addresses Scenario~S3 of the thesis, in which performance audio is the only available input and the desired output is a beat-synchronous symbolic description of dynamics. Recovering such a representation requires not only the dynamic labels themselves but also the metrical structure needed to anchor them on a score.
```

`Chapter_6/chap6.tex` line 14

```latex
From the thesis perspective, this chapter occupies a distinct position. It keeps the note-level MIDI velocity target and the score-informed VeloEst architecture introduced in Chapter~\ref{ch:scoreinf}, but it relaxes the assumption that ground-truth velocity labels are available for the target instrument. It complements Chapter~\ref{ch:audiodyn}, which addressed Scenario~S3 with a different output (beat-synchronous score dynamics), by extending the velocity-focused work to a label-scarce setting. The chapter therefore contributes to thesis Requirement~R5 by combining numerical diagnostics, perceptual loudness correlations, and renderer-robust evaluation evidence, and to Requirement~R6 by treating beyond-piano transfer as a missing-supervision problem rather than ordinary acoustic domain shift.
```

### A

No additional thesis paragraph is proposed. The existing chapter overviews explicitly state the data condition, dynamics target, and relation to the thesis question. Retain those paragraphs, subject to the specific terminology and scope corrections identified in R1-06 and R1-15.

**评价与推荐**：报告2也肯定现有chapterpositioning结构。逐章实际原文已经给scope，不为形式性满足建议堆叠同义段。最终revisionreport可准确说“保留并澄清已有联系”，不能称新增了四段若没新增。

**合并关系**：R1-06; R1-15; R2-02。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r2-02"></a>

## R2-02 四篇论文的技术贡献与 thesis 新增综合分开

**操作**：替换 §1.8 首段整体；A/B/C均为完整段落，下一原段Chapter2组织说明保持。四篇mapping与authorship reference保留，新增综合描述不声称独占或穷尽novelty。

**独立审查处理**：接受。B用实际synthesis描述替代“The thesis-level addition is”；修正round1过强理由，同时保留thesis的概念综合贡献。

**对应finding**：F14。

**实际原文与定位**

`Chapter_1/Intro.tex` line 177

```latex
Referring to Figure~\ref{fig:intro_overview}, the core methodological chapters (Chapters 3--5) preserve the technical contributions of their respective peer-reviewed publications, adapted to form a unified narrative.
```

`Chapter_1/Intro.tex` line 161

```latex
\begin{itemize}
    \item \textbf{A thesis-level formulation of dynamics-oriented label recovery.} The dissertation argues that dynamics should be treated as a primary target in expressive AMT and evaluates the robustness across diverse data distributions rather than relying on a single, idealised dataset.
    
    \item \textbf{A symbolic method for note-level velocity completion (Addressing S1).} It reformulates MIDI velocity completion as an image-colourisation problem on sparse piano-roll representations, introducing a U-Net architecture with window attention and a sparsity-aware loss \cite{he2025filling}.
```

### A

Chapters 3–6 develop the four co-authored studies listed in the Authorship Declaration. The thesis brings them together through a common dynamics-recovery question, a comparison of data-availability conditions, and a cross-chapter discussion of representation and evaluation. These thesis-level syntheses should be distinguished from the method contributions attributed to the individual studies.

### B

The technical chapters are based on four co-authored studies: symbolic velocity completion (CMMR 2025, Chapter 3), score-informed correction (SMC 2026, Chapter 4), joint dynamics and metrical estimation (ICASSP 2026, Chapter 5), and cross-instrument proxy supervision (ISMIR 2026, Chapter 6). Their authorship and publication details are listed in the Authorship Declaration. The thesis brings these studies together through a common label-recovery formulation and scenario map, provides shared background, and synthesises their assumptions and limitations in Chapter 7.

### C

The four studies address different parts of the same expressive-label problem. The technical methods are attributed to their associated co-authored papers, while the thesis develops the connections between them: which musical structure is trusted, which dynamics representation is recovered, and what supervision and evaluation support the resulting claim. This synthesis is developed in Chapters 1, 2, and 7 and in the positioning sections of the technical chapters. It should be read as the thesis contribution alongside, rather than as a replacement for, the individual method contributions.

**随后保留的上下文**

\textbf{Chapter~2} establishes the shared conceptual system, defining dynamics across audio, MIDI, and score, while reviewing baseline AMT models, datasets, and evaluation strategies.

**评价与推荐**：推荐B，明确四篇mapping并描述当前thesis实际存在的organising/synthesis工作。A更短，C更叙述化。round1理由“都能从独立论文核实新增”过强，本轮撤回该归属判断：能核实这些结构在thesis中存在，不等于证明思想首次只在thesis出现或已穷尽相对最终paper的所有新增。

**待核验／边界**：V-07仍待最终paper版本：ICASSP提供稿有PENDING等占位，不能作为clean published baseline完成exhaustive novelty diff。若GRS要求逐项adapted/new实验映射，继续待核验。四章/四paper映射及thesis概念综合价值保留。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r2-03"></a>

## R2-03 把 beyond-piano 可迁移与未验证部分写具体

**操作**：替换 Ch.7 §7.3 的 piano-centric 段；Ch.6 保留已有 attack-driven 限制，不重复加新段。

**独立审查处理**：三稿第一轮通过；按逐稿建议把C首句can transfer收窄为may transfer，推荐仍为B。

**实际原文与定位**

`Chapter_7/Conclusion.tex` line 113

```latex
Second, the strongest direct supervision in the thesis remains piano-centric. This reflects the state of available velocity-labelled datasets rather than a belief that piano dynamics is the universal template for all instruments. Chapter~\ref{ch:beyondpiano} addresses this bias by moving into a label-scarce guitar setting, but the broader point remains: once the target instrument lacks direct performance-control labels, the interpretation of recovered velocity must be stated operationally.
```

`Chapter_6/chap6.tex` line 519

```latex
Second, the experiments focus on piano and guitar. Both instruments are predominantly percussive in their attack profile, which favours the OSF parameter. Sustained-bow instruments such as violin, or breath-driven instruments such as flute, would require acoustic parameters that capture sustain and continuous-modulation cues beyond the PHE/OSF pair used here. The claim is therefore tied to the tested attack-driven setting.
```

### A

The strongest direct supervision remains piano-based. The guitar study supports the use of a renderer-conditioned onset-velocity coordinate in the tested guitar corpora, evaluated through rendered loudness rather than captured guitar velocity. It does not validate the same estimator or parameter set for voice, bowed strings, or wind instruments.

### B

The piano chapters support conclusions about the tested piano datasets and targets. Chapter 6 extends the supervision strategy to guitar, where the evidence concerns renderer-conditioned velocities and loudness agreement rather than recovery of captured physical velocity labels. Voice, bowed strings, and wind instruments were not evaluated. Their sustained dynamics and continuous controls would require suitable target coordinates and descriptors beyond the attack-focused PHE/OSF pair used here.

### C

What may transfer beyond piano is the recovery framework: specify the trusted notes, choose an editable dynamics coordinate, and match the supervision to that coordinate. The empirical evidence is narrower. It covers piano and the tested guitar adaptation, not a validated instrument-general estimator. For voice, bowed strings, and wind instruments, onset intensity alone cannot describe the sustained and continuously shaped aspects of dynamics, so the target and comparison features would need to be reconsidered.

**评价与推荐**：B直接点名examiner列的四类并区分principletransfer与performancevalidated。A最短，C很好衔接中心论点但对新乐器的目标设计论述略多。没有把guitar r当canonicalvelocityaccuracy。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r2-04"></a>

## R2-04 11位听者与8段刺激是补充证据，避免 definitive validation

**操作**：替换 Ch.3 Perceptual Evaluation 的Results段整体，保留MOS表、CI、participants/stimuli/calibration/procedure；不改成仅陈述研究意图。把样本/renderer与composer分组范围集中在此，R1-16不再重复限制。

**独立审查处理**：接受。完整Results保留已测的similarity排序；只集中一次范围说明。Abstract改assessed而不加small，Intro保留结果，Conclusion准确列Flat/ConvAE。

**对应finding**：F15。

**实际原文与定位**

`Chapter_3/chap3.tex` line 371

```latex
\paragraph{Participants.}
We recruited 11 expert listeners aged 18 or above, selected for substantial musical background and experience with critical listening studies.
Participants completed the survey anonymously through the Qualtrics platform \cite{qualtrics}.
```

`Chapter_3/chap3.tex` line 457

```latex
The evaluation design is therefore deliberately broader than a single regression score. Objective error metrics quantify note-wise accuracy, \(SD_{\mathrm{velo}}\) checks whether the predicted velocity distribution retains expressive spread, and the listening test verifies that the recovered layer changes perceived musical quality. This combination is important because a velocity-completion model can be numerically close to the target while still sounding too flat, or can sound more expressive while producing larger point-wise deviations.
```

`main.tex` line 123

```latex
%\maketitle
	\frontmatter
%	\linenumbers
	\clearpage
	\thispagestyle{empty}
	\phantom{a}
	\vfill
	\vfill
    
	\include{Declaration/declaration}
    
    
	\begin{abstract}
	Automatic music transcription has matured in its treatment of note pitch and timing, but musical dynamics remains less fully addressed. This thesis treats dynamics as a missing expressive label layer that can be recovered from music data already partly specified, without rewriting note content or note timing. Its unifying question is \emph{how musically interpretable dynamics labels can be recovered from incomplete, weakly expressive, or weakly supervised music data}. Two complementary targets within expressive music performance recur throughout: note-level MIDI velocity, the per-onset control variable used in MIDI workflows, and score-level dynamics, the beat-aligned markings such as \textit{p}, \textit{mf}, and \textit{f} written in notation.
		
	The thesis first addresses the symbolic-only setting by reformulating MIDI velocity completion as image colourisation on sparse piano-roll matrices. A U-Net with window attention and a sparsity-aware loss recovers the missing velocity layer, and the results are validated through cross-dataset objective metrics and a MUSHRA-inspired listening test.
		
	It then turns to score-informed velocity estimation in the audio-plus-score setting, using a Transformer correction module that refines AMT-estimated velocity at aligned score onsets. Rather than replacing the AMT backbone, the module uses score structure as a late correction prior, transfers across the HPT, HPPNet, and DynEst backbones, improves cross-dataset behaviour from MAESTRO to SMD, and remains stable under audio--score timing shifts of up to several seconds.
		
	A further study treats the audio-only setting with a score-facing output. It jointly estimates beat-synchronous dynamic markings, change points, beats, and downbeats from performance audio. A Bark-scale specific loudness front-end, a multi-scale encoder, and an MMoE decoder are combined to address the conflicting temporal requirements of dynamic-level estimation, change-point detection, and metrical localisation, producing output that can be written back into a score.
		
	Finally, the thesis reports an exploratory extension beyond piano. To recover note-level velocity for instruments without direct labels, it treats the problem as renderer-conditioned analysis-by-synthesis and compares two differentiable synthesis interfaces. The proposed differentiable SoundFont proxy supervises velocity through note-wise loudness-related descriptors rather than waveforms. On guitar, this proxy interface adapts a piano-pretrained estimator more reliably than a differentiable waveform synthesiser under recording mismatch.
		
	Taken together, these studies form a scenario map rather than an end-to-end pipeline. They show that dynamics recovery becomes tractable when the output layer, temporal coordinate, evidence source, and supervision regime are matched to one another. The thesis therefore extends expressive AMT beyond note detection by making existing music data more expressive, editable, and usable in settings where direct dynamics labels are partial or absent.
		
	\textbf{Keywords}: automatic music transcription; expressive music performance; MIDI velocity; dynamic markings; score-informed velocity estimation; differentiable SoundFont proxy.
	\end{abstract}
	
	\include{Acknowledgments/acknowledgements}
	
    \include{Declaration/author_declaration}
    
	\setcounter{tocdepth}{2}
	\tableofcontents
	\listoffigures
	\listoftables
	\include{Abbreviations/abbreviation}
```

`Chapter_3/chap3.tex` line 444

```latex
\paragraph{Results.}
Although a substantial gap to human performance remains, the proposed U-Net clearly outperforms the other systems.
The Flat model performs worst, consistent with earlier findings that default velocity is musically inadequate \cite{kuo2021velocity}.
The seen, less-seen, and unseen repertoire groups are best interpreted as descriptive groups rather than as a strict complexity-controlled comparison.
Even so, the relatively narrow 95\% confidence intervals across groups suggest that participants rated the stimuli with reasonable consistency.
```

### A

U-Net received higher mean similarity ratings than Flat and ConvAE on the selected excerpts, while Flat received the lowest ratings, consistent with earlier findings on default velocity \cite{kuo2021velocity}. The listening study provides supplementary perceptual evidence from 11 expert listeners, eight selected SMD excerpts, and one PianoTeq rendering configuration. The composer-group scores are descriptive rather than a controlled comparison of stylistic effects.

### B

In the listening study, U-Net received higher mean similarity ratings than Flat and ConvAE, while Flat received the lowest ratings. The 11 expert listeners evaluated eight selected SMD excerpts rendered with one PianoTeq configuration. These results provide supplementary perceptual evidence for velocity completion within that setting. The seen, less-seen, and unseen composer groups are descriptive; the selected excerpts were not balanced to isolate stylistic effects.

### C

The listener ratings favour U-Net over Flat and ConvAE in similarity to the human-performed MIDI rendering used as the reference. They provide complementary evidence alongside the note-wise objective results. This reference-based study involved 11 expert listeners, eight selected SMD excerpts, and one PianoTeq configuration, so its findings are interpreted within that setting. The composer groups describe the selected repertoire and do not isolate a stylistic effect.

**随后保留的上下文**

\section{Discussion}
\label{sec:velcomp:discussion}

This chapter has verified that note-level dynamics can be recovered usefully even when the symbolic notes and timing are held fixed. It turns expressive enhancement into a controllable post-processing stage rather than a full performance-rendering problem, which is exactly the setting encountered in many MIDI-production and corpus-curation workflows.

**评价与推荐**：推荐A：保留实际系统排序、reference-similarity目标和原有default-velocity文献，范围集中说明一次。B更像直接Results读数但不保留此句citation；C侧重与objective结果互补，未说听测验证指标本身。删除perceptual validity/population-wide musical naturalness等非本实验估计量的泛泛否定，不增加未经报告的显著性结果。MOS与CI数值不动。

**待核验／边界**：V-02 timing preparation仍待查，不在Results补未确认的timing控制。听测测的是相对human-performed MIDI rendering reference的similarity；不声称已做population naturalness研究。样本/renderer范围集中在这一处，全书同步不重复加small或总体validity否定。

**合并关系**：R1-16; R1-21。不重复实施共享文字。

**逐句同步提案**

- `main.tex` line 138
  - 原：the results are validated through cross-dataset objective metrics and a MUSHRA-inspired listening test.
  - 拟：the results are assessed through cross-dataset objective metrics and a MUSHRA-inspired listening test.

- `Chapter_3/chap3.tex` line 457
  - 原：the listening test verifies that the recovered layer changes perceived musical quality.
  - 拟：the listening study provides complementary evidence of greater perceived similarity to the reference on the selected stimuli.

- `Chapter_1/Intro.tex` line 181
  - 原：it demonstrates that recovering a decoupled expressive layer on fixed symbolic notes is enough to transform a mechanical MIDI sequence into an expressive performance.
  - 拟：it shows that velocity completion can improve expressive rendering on fixed symbolic notes, supported by objective evaluation and the listening study.

- `Chapter_7/Conclusion.tex` line 50
  - 原：yet the listening test shows a clear improvement over flat and sequence-oriented baselines.
  - 拟：and the listening study supports an improvement over Flat and ConvAE on the selected excerpts.

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

<a id="r2-05"></a>

## R2-05 只列实际见到的语言／格式问题

**操作**：只提出可核验的小修正，不批量换同义词。以下为 replacement 清单，原文及位置见本节引文。

**独立审查处理**：通过。10s/小节说明有两处不同原句：segmentation的roughly four measures at 120 BPM由R1-20处理，ablation的roughly encompasses four measures由本项处理；每个源范围各改一次，不把两处误当成同一个替换。

**实际原文与定位**

`Chapter_1/Intro.tex` line 50

```latex
Expressive AMT extends beyond note transcription to capture the full aspects of a human performance. A comprehensive expressive transcription can be conceptually divided into three layers \cite{cancinoChacon2018computational}:
\begin{itemize}
\item \textbf{Timing Layer:} Captures the temporal elasticity of a performance, including macro-level tempo variation, beat-level timing, inter-onset intervals (IOIs), and micro-level articulation.
\item \textbf{Dynamic Layer:} Represents the intensity and energy of the music performance, bridging physical machine measurements (e.g., MIDI velocity) with semantic cognitive notations (e.g., score dynamic markings).
\item \textbf{Control Layer:} Includes instrument-specific techniques and acoustic modifiers, such as sustain pedalling, vibrato, reverberation, and amplifier configurations.
\end{itemize}
While all three layers are essential for the computational understanding of expressiveness in performance, this thesis singles out the \textbf{Dynamic Layer} as its primary focus. This choice does not diminish the importance of timing or control parameters. Rather, dynamics is chosen to move AMT beyond notes for three reasons:
```

`Chapter_5/chap5.tex` line 319

```latex
The component ablations show that all major parts of the model contribute to the final performance, but not in the same way. The most diagnostic result is the removal of temporal scaling. Setting $s=1$ reduces the average F1 from 55.0 to 46.5, with particularly large drops in change-point F1 and downbeat F1. This indicates that the performance gain does not merely come from using a deeper convolutional encoder, but from exposing the downstream tasks to genuinely different temporal resolutions. Removing MMoE also degrades all four tasks, supporting the view that the four heads have different preference on the same shared latent. The overlap-based data augmentation gives a further improvement, which is expected for this dataset because change points and downbeats are sparse events. Overlapping audio segments increase the chance that such events appear in varied local contexts during training.
```

`Chapter_5/chap5.tex` line 321

```latex
The temporal-scaling results give a detailed view of the multi-scale encoder. The reference architecture of \cite{li2023frame} uses a scaling factor of 3, but this value is not optimal for our tasks combination. With $s=3$, beat F1 and change-point F1 remain strong, but the average score is lower than the full model. Increasing the factor to $s=5$ gives the best overall balance. A slightly larger value, $s=7$, remains competitive and gives the second-best average score, but further increasing the factor to $s=9$ causes a clear degradation, especially for downbeats. This pattern suggests that the model needs a sufficiently coarse branch to capture long-range dynamic context, but excessive temporal compression begins to remove information that cannot be fully recovered for event localisation. The best value is therefore not simply the largest receptive field, but the best compromise between contextual abstraction and temporal precision.
```

`Chapter_3/chap3.tex` line 358

```latex
\textbf{MIDI segment duration.} The analysis shows that reducing it from 20 to 10 seconds improves performance, while further reduction to 5 seconds slightly worsens the accuracy metrics. This is likely because a 10-second segment roughly encompasses four measures at 120 beats per minute (BPM), forming a complete musical phrase that aids in semantic segmentation.
```

### A

“capture the full aspects of a human performance” → “capture several aspects of a human performance”

“the four heads have different preference on the same shared latent” → “the four heads have different preferences for the shared representation”

“not optimal for our tasks combination” → “not optimal for this combination of tasks”

“a 10-second segment roughly encompasses four measures at 120 beats per minute (BPM)” → “a 10-second segment can span several bars, depending on tempo and metre”

**评价与推荐**：前三处是实际措辞／语法问题，最后一处是可核验时间解释。Figure2.3标题与其他排版问题须先看现存PDF页面再定，不能把PDF抽取换行自动当LaTeX缺陷。

**待核验／边界**：10s说明有两处不同源码原句：R1-20处理Chapter_3/chap3.tex第71行，R2-05处理第358行；各改一次，不重复实施。更大的事实／协议疑点仍在V-01至V-07，不能当proofreading静默修掉。

**合并关系**：R1-04; R1-20。不重复实施共享文字。

**实施**：【未执行】　**作者决定**：仅引用统一决策清单同编号。

## 仍开放的证据边界

V-01正式baseline；V-02听测timing preparation；V-03 Ch3实际run/input/loss/window；V-04 Ch4训练mode、onset-only形状、loss验证范围及SMD开发用途；V-05 Ch5 evaluator averaging与fold/表源；V-06 Fig6.3吉他GT身份；V-07最终ICASSP稿。它们不是新增examiner意见，也不因本轮英文更通顺而获关闭。

图示路线仍只是副本制作方案；未产出新图就不能把条件caption称为已匹配图像。GRS文件与唯一决定清单由各自编辑维护，本写作窗未修改。各项“独立审查处理”保留round2写作处理的历史记录；当前状态以上表及本轮定点修复为准。GRS R1-21的事实条件和V-01至V-07继续开放。
